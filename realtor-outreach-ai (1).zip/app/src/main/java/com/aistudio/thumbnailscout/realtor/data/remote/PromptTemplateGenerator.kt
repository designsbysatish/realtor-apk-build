package com.aistudio.thumbnailscout.realtor.data.remote

import com.aistudio.thumbnailscout.realtor.data.local.RealtorLeadEntity

data class OutreachTemplate(
    val id: String,
    val name: String,
    val description: String,
    val subjectVariantA: String, // Casual / Direct
    val subjectVariantB: String, // Curiosity Hook / Free Value
    val bodyTemplate: String
)

data class GeneratedEmailDraft(
    val templateId: String,
    val templateName: String,
    val subjectLine: String,
    val emailBody: String,
    val aiPromptUsed: String,
    val abVariantUsed: String = "Variant A"
)

class PromptTemplateGenerator {

    val availableTemplates: List<OutreachTemplate> = listOf(
        OutreachTemplate(
            id = "free_sample_first",
            name = "🎁 Free Sample First (Highest Reply Rate)",
            description = "Ultra-casual, ultra-friendly. Mentions you ALREADY created a free redesigned thumbnail for their specific video.",
            subjectVariantA = "quick thumbnail concept for {channelName} 🏡",
            subjectVariantB = "[Free Graphic] redesigned thumbnail for {recentVideoTitle}",
            bodyTemplate = """
                Hey {realtorName},

                Just watched your recent video "{recentVideoTitle}" while looking through real estate in {locationState}—really loved the walk-through!

                I noticed on mobile devices the thumbnail text gets a bit hard to read against the background, which might be cost-cutting your click-through rate (CTR).

                I'm a YouTube thumbnail designer specializing in US real estate. I actually went ahead and created a free redesigned thumbnail mockup specifically for "{recentVideoTitle}". 

                If you're open to taking a look, just reply to this email and I'll send over the high-res file—100% free, no catch or pressure at all!

                Best,
                {senderName}
            """.trimIndent()
        ),
        OutreachTemplate(
            id = "mobile_ctr_audit",
            name = "📱 Mobile CTR & Visual Audit Hook",
            description = "Focuses on mobile video search contrast, mobile readability, and price callouts.",
            subjectVariantA = "loved your {locationState} video (+ quick mobile thumbnail fix)",
            subjectVariantB = "mobile CTR fix for {channelName} ({locationState} real estate)",
            bodyTemplate = """
                Hi {realtorName},

                Came across {channelName} today while researching top real estate creators in {locationState}. Great video on "{recentVideoTitle}"!

                Here's a quick observation: {thumbnailImprovementNote}

                Because over 70% of home buyers browse YouTube on their phones, fixing this mobile contrast issue can quickly boost your video CTR.

                I put together a high-CTR graphic redesign with bold 3D text overlay and warm interior lighting. Would you like me to email you the free sample graphic?

                Cheers,
                {senderName}
            """.trimIndent()
        ),
        OutreachTemplate(
            id = "competitor_benchmark",
            name = "🏆 Competitor Benchmark Style",
            description = "Compares channel presentation against top performing US realtors in their state.",
            subjectVariantA = "comparing {channelName} vs top {locationState} realtors",
            subjectVariantB = "how top {locationState} realtors get 3x more thumbnail clicks",
            bodyTemplate = """
                Hey {realtorName},

                Hope you're having a great week! I was analyzing top performing realtor YouTube channels in {locationState} and stumbled upon "{recentVideoTitle}".

                Your content presentation is solid, but here is what top regional channels are doing differently: {competitorBenchmarkComparison}

                I designed a high-converting thumbnail upgrade for your video to match those top industry visual standards. 

                Let me know if I can drop the free sample file in your inbox!

                Best regards,
                {senderName}
            """.trimIndent()
        ),
        OutreachTemplate(
            id = "short_curiosity",
            name = "⚡ Short Curiosity Soft Intro (1-Min Read)",
            description = "Super concise, 3-sentence email that gets opened and replied to fast.",
            subjectVariantA = "quick question regarding {recentVideoTitle}",
            subjectVariantB = "idea for {channelName}'s latest house tour",
            bodyTemplate = """
                Hey {realtorName},

                Loved your breakdown in "{recentVideoTitle}"! 

                I created a quick redesigned thumbnail mockup for this video that boosts mobile click-through rates for {locationState} realtors.

                Mind if I send the free graphic over to your email? No obligations at all!

                Best,
                {senderName}
            """.trimIndent()
        )
    )

    /**
     * Generates a fully personalized human outreach email draft based on lead data and template, supporting A/B subject variants.
     */
    fun craftEmailFromTemplate(
        template: OutreachTemplate,
        lead: RealtorLeadEntity,
        senderName: String,
        preferredVariant: String = "AUTO"
    ): GeneratedEmailDraft {
        val cleanRealtorName = if (lead.realtorName.isNotBlank() && lead.realtorName != "Realtor") lead.realtorName else "there"
        val cleanChannel = lead.channelName.ifBlank { "your channel" }
        val cleanVideo = lead.recentVideoTitle.ifBlank { "your recent house tour" }
        val cleanLocation = lead.locationState.ifBlank { "US" }
        val cleanWeakness = lead.thumbnailImprovementNote.ifBlank { "Current thumbnail text contrast is low on mobile devices." }
        val cleanComp = lead.competitorBenchmarkComparison.ifBlank { "Top regional creators use high-contrast 3D price tags and HDR lighting." }
        val cleanSender = senderName.ifBlank { "Rahul" }
        val cleanSubs = if (lead.subscriberCount > 0) "${lead.subscriberCount} subs" else "your audience"
        val cleanViews = if (lead.avgViews > 0) "${lead.avgViews} views" else "your view count"
        val cleanScore = "${lead.currentThumbnailRatingScore}/10"

        val chosenVariant = when (preferredVariant) {
            "Variant A" -> "Variant A"
            "Variant B" -> "Variant B"
            else -> if (lead.id.hashCode() % 2 == 0) "Variant A" else "Variant B"
        }

        val rawSubject = if (chosenVariant == "Variant B") template.subjectVariantB else template.subjectVariantA

        val subject = rawSubject
            .replace("{channelName}", cleanChannel)
            .replace("{realtorName}", cleanRealtorName)
            .replace("{recentVideoTitle}", cleanVideo)
            .replace("{locationState}", cleanLocation)
            .replace("{senderName}", cleanSender)
            .replace("{subscriberCount}", cleanSubs)
            .replace("{avgViews}", cleanViews)
            .replace("{thumbnailScore}", cleanScore)

        val body = template.bodyTemplate
            .replace("{channelName}", cleanChannel)
            .replace("{realtorName}", cleanRealtorName)
            .replace("{recentVideoTitle}", cleanVideo)
            .replace("{locationState}", cleanLocation)
            .replace("{thumbnailImprovementNote}", cleanWeakness)
            .replace("{competitorBenchmarkComparison}", cleanComp)
            .replace("{senderName}", cleanSender)
            .replace("{subscriberCount}", cleanSubs)
            .replace("{avgViews}", cleanViews)
            .replace("{thumbnailScore}", cleanScore)

        val promptText = buildGeminiPrompt(template, lead, senderName)

        return GeneratedEmailDraft(
            templateId = template.id,
            templateName = template.name,
            subjectLine = subject,
            emailBody = body,
            aiPromptUsed = promptText,
            abVariantUsed = chosenVariant
        )
    }

    /**
     * Constructs the exact prompt template used to feed Gemini for generating natural, human-sounding outreach.
     */
    fun buildGeminiPrompt(
        template: OutreachTemplate,
        lead: RealtorLeadEntity,
        senderName: String
    ): String {
        return """
            Target US Realtor Channel: ${lead.channelName}
            Realtor Name: ${lead.realtorName}
            Recent Video Title: "${lead.recentVideoTitle}"
            Market Location: ${lead.locationState}
            Subscribers: ${lead.subscriberCount}
            Avg Views: ${lead.avgViews}
            Weakness Analysis: ${lead.thumbnailImprovementNote}
            Competitor Comparison: ${lead.competitorBenchmarkComparison}
            Outreach Designer: $senderName
            Selected Strategy Template: ${template.name}
            
            Instruction: Write a 100% human, non-ai-sounding outreach email and subject line offering a free redesigned thumbnail sample.
        """.trimIndent()
    }
}
