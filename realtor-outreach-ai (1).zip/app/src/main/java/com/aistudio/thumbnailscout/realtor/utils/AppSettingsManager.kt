package com.aistudio.thumbnailscout.realtor.utils

import android.content.Context
import android.content.SharedPreferences

object AppSettingsManager {
    private const val PREF_NAME = "ThumbnailScoutMasterPrefs"
    
    private fun getPrefs(context: Context): SharedPreferences {
        return context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
    }

    // --- 1. Profile & Niche Settings ---
    var designerName: String
        get() = getPrefs(AppInstance.context).getString("designer_name", "Satish Jaiswal") ?: "Satish Jaiswal"
        set(value) = getPrefs(AppInstance.context).edit().putString("designer_name", value).apply()

    var designerEmail: String
        get() = getPrefs(AppInstance.context).getString("designer_email", "designer@realtorthumbnails.com") ?: ""
        set(value) = getPrefs(AppInstance.context).edit().putString("designer_email", value).apply()

    var targetNiche: String
        get() = getPrefs(AppInstance.context).getString("target_niche", "Real Estate & Documentaries") ?: "Real Estate"
        set(value) = getPrefs(AppInstance.context).edit().putString("target_niche", value).apply()

    var targetCountry: String
        get() = getPrefs(AppInstance.context).getString("target_country", "US") ?: "US"
        set(value) = getPrefs(AppInstance.context).edit().putString("target_country", value).apply()

    // --- 2. Business & Pricing Settings ---
    var pricePerThumbnail: String
        get() = getPrefs(AppInstance.context).getString("price_thumbnail", "$10") ?: "$10"
        set(value) = getPrefs(AppInstance.context).edit().putString("price_thumbnail", value).apply()

    var revisionPolicy: String
        get() = getPrefs(AppInstance.context).getString("revision_policy", "Unlimited Revisions") ?: "Unlimited Revisions"
        set(value) = getPrefs(AppInstance.context).edit().putString("revision_policy", value).apply()

    var portfolioUrl: String
        get() = getPrefs(AppInstance.context).getString("portfolio_url", "https://tinyurl.com/satish-thumbnails") ?: "https://tinyurl.com/satish-thumbnails"
        set(value) = getPrefs(AppInstance.context).edit().putString("portfolio_url", value).apply()

    var paypalUrl: String
        get() = getPrefs(AppInstance.context).getString("paypal_url", "https://paypal.me/SatishDesigns") ?: "https://paypal.me/SatishDesigns"
        set(value) = getPrefs(AppInstance.context).edit().putString("paypal_url", value).apply()

    // --- 3. Core API Configurations ---
    var geminiApiKey: String
        get() = getPrefs(AppInstance.context).getString("gemini_key", "") ?: ""
        set(value) = getPrefs(AppInstance.context).edit().putString("gemini_key", value).apply()

    var youtubeApiKey: String
        get() = getPrefs(AppInstance.context).getString("youtube_key", "") ?: ""
        set(value) = getPrefs(AppInstance.context).edit().putString("youtube_key", value).apply()

    var gmailUser: String
        get() = getPrefs(AppInstance.context).getString("gmail_user", "") ?: ""
        set(value) = getPrefs(AppInstance.context).edit().putString("gmail_user", value).apply()

    var gmailAppPass: String
        get() = getPrefs(AppInstance.context).getString("gmail_pass", "") ?: ""
        set(value) = getPrefs(AppInstance.context).edit().putString("gmail_pass", value).apply()

    // --- 4. Future / Optional AI Slots ---
    var openAiApiKey: String
        get() = getPrefs(AppInstance.context).getString("openai_key", "") ?: ""
        set(value) = getPrefs(AppInstance.context).edit().putString("openai_key", value).apply()

    var deepSeekApiKey: String
        get() = getPrefs(AppInstance.context).getString("deepseek_key", "") ?: ""
        set(value) = getPrefs(AppInstance.context).edit().putString("deepseek_key", value).apply()

    // --- 5. Automation & Throttle ---
    var dripDelaySeconds: Int
        get() = getPrefs(AppInstance.context).getInt("drip_delay", 41)
        set(value) = getPrefs(AppInstance.context).edit().putInt("drip_delay", value).apply()

    // --- 6. AI Boss & Targets ---
    var dailyTargetOutreach: Int
        get() = getPrefs(AppInstance.context).getInt("daily_target", 20)
        set(value) = getPrefs(AppInstance.context).edit().putInt("daily_target", value).apply()

    var monthlyGoalUsd: Int
        get() = getPrefs(AppInstance.context).getInt("monthly_goal", 1500)
        set(value) = getPrefs(AppInstance.context).edit().putInt("monthly_goal", value).apply()
}

// Simple Context Holder helper
object AppInstance {
    lateinit var context: Context
}
