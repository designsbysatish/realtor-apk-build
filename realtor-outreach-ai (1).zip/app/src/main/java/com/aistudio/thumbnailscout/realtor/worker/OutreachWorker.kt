package com.aistudio.thumbnailscout.realtor.worker

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.aistudio.thumbnailscout.realtor.data.local.AppDatabase
// import com.aistudio.thumbnailscout.ai.AIAgentEngine
import com.aistudio.thumbnailscout.realtor.utils.GmailSender
import com.aistudio.thumbnailscout.realtor.utils.AppSettingsManager
import kotlinx.coroutines.delay

class OutreachWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val database = AppDatabase.getDatabase(applicationContext)
        val dao = database.realtorLeadDao()

        // Apni Gmail ID aur Google App Password yahan daalein (Free & Secure)
        val senderEmail = AppSettingsManager.gmailUser
        val appPassword = AppSettingsManager.gmailAppPass

        // Dummy ya Database ki pending leads fetch karein
        // Yahan hum simulation/loop chala rahe hain 5-second gap ke sath
        val targetEmail = "realtor.client@example.com"
        val channelName = "USA Homes"
        val recentVideo = "Market Update 2026"

        try {
            // val emailBody = AIAgentEngine.generateHumanOutreachEmail(channelName, recentVideo)
            val emailBody = "Subject: Quick thumbnail thought for $channelName\n\nThis is a test email."
            
            // Gmail ke zariye email dispatch
            GmailSender.sendEmail(
                senderEmail = senderEmail,
                appPassword = appPassword,
                recipientEmail = targetEmail,
                subject = "Quick thumbnail thought for $channelName",
                body = emailBody
            )

            // Staggering Delay: Exact 5 seconds delay to prevent spam detection
            delay(5000L)

            return Result.success()
        } catch (e: Exception) {
            e.printStackTrace()
            return Result.retry()
        }
    }
}
