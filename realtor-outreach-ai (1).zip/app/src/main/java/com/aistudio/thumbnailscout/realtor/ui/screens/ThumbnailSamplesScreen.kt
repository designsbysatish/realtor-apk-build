package com.aistudio.thumbnailscout.realtor.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aistudio.thumbnailscout.ai.AIThumbnailGenerator

@Composable
fun ThumbnailSamplesScreen() {
    val generator = remember { AIThumbnailGenerator() }
    
    // Sample channel input
    val channelName = "USA Real Estate Pro"
    val videoTopic = "Market Update 2026"
    val samples = remember { generator.generateThumbnailSamples(channelName, videoTopic) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("🎨 AI Channel Analyzer & 3 Thumbnail Options", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        Text("Target Channel: $channelName", fontSize = 14.sp, fontWeight = FontWeight.Medium)
        
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text("🔥 Special Deal Attached:", fontWeight = FontWeight.Bold)
                Text("• Price: $10 per Thumbnail\n• Policy: Unlimited Revisions Included\n• Portfolio: tinyurl.com/satish-thumbnails\n• PayPal: https://paypal.me/SatishDesigns", fontSize = 13.sp)
            }
        }

        Spacer(modifier = Modifier.height(4.dp))
        Text("Generated High-CTR Sample Concepts:", fontWeight = FontWeight.Bold, fontSize = 16.sp)

        samples.forEach { sample ->
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Option ${sample.optionNumber}: \"${sample.headline}\"", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = MaterialTheme.colorScheme.secondary)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("🖼️ Layout & Visual: ${sample.visualStyle}", fontSize = 13.sp)
                    Text("🎨 Color Palette: ${sample.colorScheme}", fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    Surface(
                        color = MaterialTheme.colorScheme.tertiaryContainer,
                        shape = MaterialTheme.shapes.small
                    ) {
                        Text(
                            text = "Offer: ${sample.pricingOffer}",
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}
