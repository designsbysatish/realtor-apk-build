package com.aistudio.thumbnailscout.realtor.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aistudio.thumbnailscout.realtor.utils.AIBossAgent
import com.aistudio.thumbnailscout.realtor.utils.AppSettingsManager

@Composable
fun AIBossDashboardScreen() {
    val context = LocalContext.current
    val bossAgent = remember { AIBossAgent(context) }

    val todayTarget = AppSettingsManager.dailyTargetOutreach
    var doneOutreach by remember { mutableStateOf(5) } // In a real app, fetch from DB
    val monthlyGoalUsd = AppSettingsManager.monthlyGoalUsd

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("⚡ AI Strict Boss & Growth Coach", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.error)
        Text("Yeh AI aapko kabhi aaram nahi karne dega. Target miss hua toh daant padegi!", fontSize = 13.sp)

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("🎯 Aaj ka Target Status:", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Spacer(modifier = Modifier.height(8.dp))
                Text("• Target Outreach: $todayTarget Realtors")
                Text("• Done Today: $doneOutreach Realtors")
                Text("• Monthly Goal: \$$monthlyGoalUsd USD")
                
                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = {
                        // Boss se daant khane aur status check karne ke liye button
                        bossAgent.scoldAndGiveTarget(doneOutreach, todayTarget, monthlyGoalUsd)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("🗣️ AI Boss se Check Karwayen (Daant aur Target)")
                }
            }
        }

        // Test Alarms for Email Seen / Reply
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("🔔 Live Simulation & Alarms", fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(8.dp))
                
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = {
                        bossAgent.triggerEmailSeenAlert("USA Realtor John")
                    }, modifier = Modifier.weight(1f)) {
                        Text("Test Seen Alarm")
                    }
                    
                    Button(onClick = {
                        bossAgent.triggerClientReplyAlert("Miami Homes", "I want the thumbnail, send PayPal!")
                    }, modifier = Modifier.weight(1f)) {
                        Text("Test Reply Alert")
                    }
                }
            }
        }
    }
}
