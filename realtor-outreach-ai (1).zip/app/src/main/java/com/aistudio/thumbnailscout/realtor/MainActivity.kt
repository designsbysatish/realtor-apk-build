package com.aistudio.thumbnailscout.realtor

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.MarkEmailUnread
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Radar
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aistudio.thumbnailscout.realtor.ui.components.HeaderBar
import com.aistudio.thumbnailscout.realtor.ui.components.LeadAuditModal
import com.aistudio.thumbnailscout.realtor.ui.components.VoiceAssistantDialog
import com.aistudio.thumbnailscout.realtor.ui.screens.AnalyticsTrackerScreen
import com.aistudio.thumbnailscout.realtor.ui.screens.ClientHubScreen
import com.aistudio.thumbnailscout.realtor.ui.screens.DiagnosticTestScreen
import com.aistudio.thumbnailscout.realtor.ui.screens.HomeScreen
import com.aistudio.thumbnailscout.realtor.ui.screens.LeadsBoxScreen
import com.aistudio.thumbnailscout.realtor.ui.screens.MasterSettingsScreen
import com.aistudio.thumbnailscout.realtor.ui.screens.OutreachedBoxScreen
import com.aistudio.thumbnailscout.realtor.ui.screens.PinLockScreen
import com.aistudio.thumbnailscout.realtor.ui.screens.ScanDiscoveryScreen
import com.aistudio.thumbnailscout.realtor.ui.screens.SettingsScreen
import com.aistudio.thumbnailscout.realtor.ui.theme.DarkNavySurface
import com.aistudio.thumbnailscout.realtor.ui.theme.DarkNavySurfaceVariant
import com.aistudio.thumbnailscout.realtor.ui.theme.DeepSlateBackground
import com.aistudio.thumbnailscout.realtor.ui.theme.GoldAccent
import com.aistudio.thumbnailscout.realtor.ui.theme.TextPrimaryLight
import com.aistudio.thumbnailscout.realtor.ui.theme.TextSecondaryLight
import com.aistudio.thumbnailscout.realtor.ui.theme.ThumbnailScoutTheme
import com.aistudio.thumbnailscout.realtor.ui.viewmodel.MainViewModel
import com.aistudio.thumbnailscout.realtor.ui.viewmodel.NavigationTab

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val themeMode by viewModel.themeMode.collectAsState()
            val isDark = when (themeMode) {
                "DARK" -> true
                "LIGHT" -> false
                else -> androidx.compose.foundation.isSystemInDarkTheme()
            }
            
            ThumbnailScoutTheme(darkTheme = isDark) {
                MainAppContent(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun MainAppContent(viewModel: MainViewModel) {
    val currentTab by viewModel.currentTab.collectAsState()
    val filteredLeads by viewModel.filteredLeads.collectAsState()
    val allLeads by viewModel.allLeads.collectAsState()
    val selectedLead by viewModel.selectedLead.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val activeFilter by viewModel.filterCategory.collectAsState()
    val selectedPriorityCategory by viewModel.selectedPriorityCategory.collectAsState()
    val selectedOutreachStatus by viewModel.selectedOutreachStatus.collectAsState()
    val isScanning by viewModel.isScanning.collectAsState()
    val recentLogs by viewModel.recentLogs.collectAsState()

    val totalLeadCount by viewModel.totalLeadCount.collectAsState()
    val outreachedCount by viewModel.outreachedCount.collectAsState()
    val repliedCount by viewModel.repliedCount.collectAsState()
    val trackingMetrics by viewModel.trackingMetrics.collectAsState()
    val abTestMetrics by viewModel.abTestMetrics.collectAsState()
    val dispatchState by viewModel.dispatchProgress.collectAsState()
    val voiceMessage by viewModel.voiceOutputMessage.collectAsState()

    var showVoiceDialog by remember { mutableStateOf(false) }
    var isSettingsUnlocked by remember { mutableStateOf(false) }
    
    // Reset unlock state when switching tabs
    LaunchedEffect(currentTab) {
        if (currentTab !is NavigationTab.Settings) {
            isSettingsUnlocked = false
        }
    }

    Scaffold(
        topBar = {
            HeaderBar(
                totalLeadsCount = totalLeadCount,
                outreachedCount = outreachedCount,
                dispatchState = dispatchState,
                onVoiceClick = { showVoiceDialog = true },
                onBulkDispatchClick = {
                    val readyLeads = allLeads.filter { it.status == "DISCOVERED" || it.status == "AUDITED" }
                    viewModel.startBulkAutomatedOutreach(readyLeads)
                }
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 8.dp
            ) {
                NavigationBarItem(
                    selected = currentTab is NavigationTab.Home,
                    onClick = { viewModel.switchTab(NavigationTab.Home) },
                    icon = { Icon(Icons.Default.Dashboard, contentDescription = "Home") },
                    label = { Text("Home", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = MaterialTheme.colorScheme.primary,
                        selectedTextColor = MaterialTheme.colorScheme.primary,
                        indicatorColor = MaterialTheme.colorScheme.surfaceVariant,
                        unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                        unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                    ),
                    modifier = Modifier.testTag("tab_home")
                )

                NavigationBarItem(
                    selected = currentTab is NavigationTab.LeadsBox,
                    onClick = { viewModel.switchTab(NavigationTab.LeadsBox) },
                    icon = { Icon(Icons.Default.MarkEmailUnread, contentDescription = "New Leads") },
                    label = { Text("New Leads", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = MaterialTheme.colorScheme.primary,
                        selectedTextColor = MaterialTheme.colorScheme.primary,
                        indicatorColor = MaterialTheme.colorScheme.surfaceVariant,
                        unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                        unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                    ),
                    modifier = Modifier.testTag("tab_leads_box")
                )

                NavigationBarItem(
                    selected = currentTab is NavigationTab.ScanDiscovery,
                    onClick = { viewModel.switchTab(NavigationTab.ScanDiscovery) },
                    icon = { Icon(Icons.Default.Radar, contentDescription = "Channel Scan") },
                    label = { Text("Live Scan", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = MaterialTheme.colorScheme.primary,
                        selectedTextColor = MaterialTheme.colorScheme.primary,
                        indicatorColor = MaterialTheme.colorScheme.surfaceVariant,
                        unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                        unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                    ),
                    modifier = Modifier.testTag("tab_scan_discovery")
                )

                NavigationBarItem(
                    selected = currentTab is NavigationTab.OutreachedBox,
                    onClick = { viewModel.switchTab(NavigationTab.OutreachedBox) },
                    icon = { Icon(Icons.Default.Send, contentDescription = "Sent Outreach") },
                    label = { Text("Outreached", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = MaterialTheme.colorScheme.primary,
                        selectedTextColor = MaterialTheme.colorScheme.primary,
                        indicatorColor = MaterialTheme.colorScheme.surfaceVariant,
                        unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                        unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                    ),
                    modifier = Modifier.testTag("tab_outreached_box")
                )

                NavigationBarItem(
                    selected = currentTab is NavigationTab.AnalyticsTracker,
                    onClick = { viewModel.switchTab(NavigationTab.AnalyticsTracker) },
                    icon = { Icon(Icons.Default.Analytics, contentDescription = "CTR Tracker") },
                    label = { Text("CTR Analytics", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = MaterialTheme.colorScheme.primary,
                        selectedTextColor = MaterialTheme.colorScheme.primary,
                        indicatorColor = MaterialTheme.colorScheme.surfaceVariant,
                        unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                        unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                    ),
                    modifier = Modifier.testTag("tab_analytics_tracker")
                )

                NavigationBarItem(
                    selected = currentTab is NavigationTab.ClientHub,
                    onClick = { viewModel.switchTab(NavigationTab.ClientHub) },
                    icon = { Icon(Icons.Default.Person, contentDescription = "Client Hub") },
                    label = { Text("Client Hub", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = MaterialTheme.colorScheme.primary,
                        selectedTextColor = MaterialTheme.colorScheme.primary,
                        indicatorColor = MaterialTheme.colorScheme.surfaceVariant,
                        unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                        unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                    ),
                    modifier = Modifier.testTag("tab_client_hub")
                )

                NavigationBarItem(
                    selected = currentTab is NavigationTab.DiagnosticTest,
                    onClick = { viewModel.switchTab(NavigationTab.DiagnosticTest) },
                    icon = { Icon(Icons.Default.BugReport, contentDescription = "Diagnostics") },
                    label = { Text("Health", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = MaterialTheme.colorScheme.primary,
                        selectedTextColor = MaterialTheme.colorScheme.primary,
                        indicatorColor = MaterialTheme.colorScheme.surfaceVariant,
                        unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                        unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                    ),
                    modifier = Modifier.testTag("tab_diagnostic")
                )

                NavigationBarItem(
                    selected = currentTab is NavigationTab.Settings,
                    onClick = { viewModel.switchTab(NavigationTab.Settings) },
                    icon = { Icon(Icons.Default.Settings, contentDescription = "Settings") },
                    label = { Text("Settings", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = MaterialTheme.colorScheme.primary,
                        selectedTextColor = MaterialTheme.colorScheme.primary,
                        indicatorColor = MaterialTheme.colorScheme.surfaceVariant,
                        unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                        unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                    ),
                    modifier = Modifier.testTag("tab_settings")
                )
            }
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            when (currentTab) {
                is NavigationTab.Home -> {
                    HomeScreen(
                        leadCount = totalLeadCount,
                        outreachedCount = outreachedCount,
                        repliedCount = repliedCount,
                        recentLogs = recentLogs,
                        highPriorityLeads = allLeads.filter { it.currentThumbnailRatingScore <= 2 },
                        onLeadClick = { viewModel.selectLead(it) },
                        onVoiceAssistantClick = { showVoiceDialog = true }
                    )
                }

                is NavigationTab.LeadsBox -> {
                    LeadsBoxScreen(
                        leads = allLeads,
                        searchQuery = viewModel.searchQuery.collectAsState().value,
                        onSearchQueryChange = { viewModel.setSearchQuery(it) },
                        activeFilter = viewModel.filterCategory.collectAsState().value,
                        onFilterChange = { viewModel.setFilterCategory(it) },
                        onSendGmailClick = { 
                            val readyLeads = allLeads.filter { it.status == "READY" }
                            if (readyLeads.isNotEmpty()) {
                                viewModel.scheduleWorkManagerOutreachQueue(readyLeads)
                            }
                        },
                        onMarkRepliedClick = { viewModel.markLeadAsReplied(it) },
                        onScanMoreClick = { viewModel.switchTab(NavigationTab.ScanDiscovery) },
                        onLeadClick = { viewModel.selectLead(it) }
                    )
                }

                is NavigationTab.ScanDiscovery -> {
                    ScanDiscoveryScreen(
                        isScanning = isScanning,
                        onStartScan = { keyword -> viewModel.scanNewLeads(keyword) }
                    )
                }

                is NavigationTab.OutreachedBox -> {
                    OutreachedBoxScreen(
                        outreachedLeads = allLeads.filter { it.status == "SENT" || it.status == "SEEN" || it.status == "REPLIED" },
                        dispatchState = dispatchState,
                        targetTimezone = viewModel.preferences.targetTimezone,
                        onLeadClick = { viewModel.selectLead(it) },
                        onBulkDispatchClick = {
                            val readyLeads = allLeads.filter { it.status == "DISCOVERED" || it.status == "AUDITED" }
                            viewModel.startBulkAutomatedOutreach(readyLeads)
                        },
                        onSimulatePixelOpen = { viewModel.simulatePixelOpen(it) },
                        onWorkManagerQueueClick = { antiSpamSec, respectHours ->
                            val readyLeads = allLeads.filter { it.status == "DISCOVERED" || it.status == "AUDITED" }
                            viewModel.scheduleWorkManagerOutreachQueue(readyLeads, antiSpamSec, respectHours)
                        },
                        onCancelWorkManagerClick = { viewModel.cancelWorkManagerQueue() }
                    )
                }

                is NavigationTab.AnalyticsTracker -> {
                    AnalyticsTrackerScreen(
                        totalLeads = totalLeadCount,
                        outreachedCount = outreachedCount,
                        repliedCount = repliedCount,
                        trackingMetrics = trackingMetrics,
                        abTestMetrics = abTestMetrics,
                        logs = recentLogs,
                        onSimulateABPing = { viewModel.simulateABTestOpenPings() }
                    )
                }

                is NavigationTab.ClientHub -> {
                    ClientHubScreen()
                }

                is NavigationTab.Settings -> {
                    if (isSettingsUnlocked) {
                        MasterSettingsScreen()
                    } else {
                        PinLockScreen(onUnlocked = { isSettingsUnlocked = true })
                    }
                }

                is NavigationTab.DiagnosticTest -> {
                    DiagnosticTestScreen(preferences = viewModel.preferences)
                }
            }

            // Lead Detail / Audit Modal
            selectedLead?.let { lead ->
                LeadAuditModal(
                    lead = lead,
                    onDismiss = { viewModel.selectLead(null) },
                    onSaveEmailDraft = { subject, body, comment ->
                        viewModel.updateLeadEmailDraft(subject, body, comment)
                    },
                    onSendSingleEmail = { leadToSend ->
                        viewModel.startBulkAutomatedOutreach(listOf(leadToSend))
                    },
                    onOpenGmailIntent = { leadToGmail ->
                        viewModel.launchSingleOutreachInGmail(leadToGmail)
                    },
                    onRefreshAudit = {
                        viewModel.regenerateAuditForSelectedLead()
                    },
                    onMarkReplied = { leadReplied ->
                        viewModel.markLeadAsReplied(leadReplied)
                    },
                    onSimulatePixelOpen = { leadToTrigger ->
                        viewModel.simulatePixelOpen(leadToTrigger)
                    },
                    onApplyTemplate = { templateId ->
                        viewModel.applyOutreachTemplate(lead, templateId)
                    },
                    onAuditVisionClick = {
                        viewModel.auditThumbnailWithGeminiVision(lead)
                    }
                )
            }

            // Voice Assistant Modal
            if (showVoiceDialog) {
                VoiceAssistantDialog(
                    onDismiss = { showVoiceDialog = false },
                    agentResponse = voiceMessage,
                    onSendCommand = { cmd -> viewModel.processAgentVoiceCommand(cmd) }
                )
            }
        }
    }
}
