package com.aistudio.thumbnailscout.realtor.data.remote

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

object TimezoneUtils {

    /**
     * Determines the US timezone ID based on state code or city in location string.
     */
    fun getTimezoneForLocation(locationState: String): String {
        val upper = locationState.uppercase()
        return when {
            upper.contains("CA") || upper.contains("WA") || upper.contains("OR") || upper.contains("NV") -> "US/Pacific"
            upper.contains("CO") || upper.contains("UT") || upper.contains("AZ") || upper.contains("NM") || upper.contains("ID") || upper.contains("MT") || upper.contains("WY") -> "US/Mountain"
            upper.contains("TX") || upper.contains("IL") || upper.contains("TN") || upper.contains("MO") || upper.contains("WI") || upper.contains("MN") || upper.contains("AL") || upper.contains("LA") || upper.contains("OK") || upper.contains("KS") -> "US/Central"
            else -> "US/Eastern" // FL, NY, GA, NC, VA, PA, OH, MI, MA, NJ, etc.
        }
    }

    /**
     * Returns short friendly timezone label like "EST", "CST", "MST", "PST"
     */
    fun getTimezoneCode(locationState: String): String {
        return when (getTimezoneForLocation(locationState)) {
            "US/Pacific" -> "PST"
            "US/Mountain" -> "MST"
            "US/Central" -> "CST"
            else -> "EST"
        }
    }

    /**
     * Calculates delay in seconds to ensure outreach lands in business hours (9 AM - 5 PM) in local timezone,
     * staggered with anti-spam random delay intervals to prevent IP/domain spam flags.
     */
    fun calculateTimezoneStaggeredDelaySeconds(
        locationState: String,
        staggerIndex: Int,
        minAntiSpamIntervalSec: Long = 180L, // 3 minutes default anti-spam interval
        respectBusinessHours: Boolean = true
    ): Long {
        val tzId = getTimezoneForLocation(locationState)
        val tz = TimeZone.getTimeZone(tzId)
        val now = System.currentTimeMillis()

        // Anti-spam jitter: minInterval + 30-90s natural variation per email
        val baseAntiSpamDelay = (staggerIndex * minAntiSpamIntervalSec) + (staggerIndex * 45)

        if (!respectBusinessHours) {
            return baseAntiSpamDelay
        }

        val cal = Calendar.getInstance(tz)
        cal.timeInMillis = now + (baseAntiSpamDelay * 1000L)
        val hourOfDay = cal.get(Calendar.HOUR_OF_DAY)

        // Business hours target: 9 AM to 5 PM local time
        return if (hourOfDay < 9) {
            // Before 9 AM -> delay until 9:00 AM local time
            cal.set(Calendar.HOUR_OF_DAY, 9)
            cal.set(Calendar.MINUTE, (staggerIndex * 5) % 45)
            cal.set(Calendar.SECOND, 0)
            ((cal.timeInMillis - now) / 1000L).coerceAtLeast(baseAntiSpamDelay)
        } else if (hourOfDay >= 17) {
            // After 5 PM -> delay until 9:15 AM next morning local time
            cal.add(Calendar.DAY_OF_YEAR, 1)
            cal.set(Calendar.HOUR_OF_DAY, 9)
            cal.set(Calendar.MINUTE, 15 + ((staggerIndex * 5) % 40))
            cal.set(Calendar.SECOND, 0)
            ((cal.timeInMillis - now) / 1000L).coerceAtLeast(baseAntiSpamDelay)
        } else {
            baseAntiSpamDelay
        }
    }

    fun getFormattedTimeInZone(tzId: String): String {
        return try {
            val sdf = SimpleDateFormat("hh:mm a", Locale.US)
            sdf.timeZone = TimeZone.getTimeZone(tzId)
            sdf.format(Date())
        } catch (e: Exception) {
            "10:00 AM"
        }
    }
}
