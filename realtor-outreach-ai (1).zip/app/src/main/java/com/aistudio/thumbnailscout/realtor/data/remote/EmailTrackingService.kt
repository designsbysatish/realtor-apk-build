package com.aistudio.thumbnailscout.realtor.data.remote

import com.aistudio.thumbnailscout.realtor.data.local.RealtorLeadEntity
import java.util.UUID
import kotlin.math.roundToInt

data class TrackingPixelInfo(
    val pixelId: String,
    val pixelUrl: String,
    val htmlPixelTag: String,
    val trackingIdentifier: String
)

data class EmailTrackingMetrics(
    val totalSent: Int,
    val totalSeen: Int,
    val totalUnseen: Int,
    val openRatePercentage: Int
)

data class ABTestMetrics(
    val variantASentCount: Int,
    val variantASeenCount: Int,
    val variantAOpenRate: Int,
    val variantBSentCount: Int,
    val variantBSeenCount: Int,
    val variantBOpenRate: Int,
    val winningVariant: String, // "Variant A", "Variant B", or "Tied"
    val liftPercentage: Int,
    val variantASample: String = "quick thumbnail concept for {channelName} 🏡",
    val variantBSample: String = "[Free Graphic] redesigned thumbnail for {recentVideoTitle}"
)

class EmailTrackingService {

    /**
     * Generates a unique tracking pixel payload for a specific lead outreach email.
     */
    fun generateTrackingPixel(leadId: Long): TrackingPixelInfo {
        val uniqueHash = UUID.randomUUID().toString().take(8)
        val pixelId = "px_${leadId}_$uniqueHash"
        val pixelUrl = "https://tracker.thumbnailscout.ai/px/$pixelId.gif"
        
        val htmlTag = """
            <img src="$pixelUrl" width="1" height="1" style="display:none !important; visibility:hidden; width:1px; height:1px;" alt="pixel" />
        """.trimIndent()
        
        return TrackingPixelInfo(
            pixelId = pixelId,
            pixelUrl = pixelUrl,
            htmlPixelTag = htmlTag,
            trackingIdentifier = "Ref: #$pixelId"
        )
    }

    /**
     * Injects the invisible 1x1 tracking pixel and unique tracking reference code into the email body text.
     */
    fun injectTrackingPixel(emailBody: String, pixelInfo: TrackingPixelInfo): String {
        return buildString {
            append(emailBody.trim())
            append("\n\n---\n")
            append(pixelInfo.trackingIdentifier)
            append("\n")
            append(pixelInfo.htmlPixelTag)
        }
    }

    /**
     * Process a simulated or live tracking pixel ping when the email recipient opens the email.
     */
    fun processPixelHit(lead: RealtorLeadEntity): RealtorLeadEntity {
        val now = System.currentTimeMillis()
        val newOpenCount = lead.openCount + 1
        val newStatus = if (lead.status == "SENT" || lead.status == "DISCOVERED" || lead.status == "AUDITED") "SEEN" else lead.status
        
        return lead.copy(
            isSeen = true,
            status = newStatus,
            openCount = newOpenCount,
            openedTimestamp = if (lead.openedTimestamp == 0L) now else lead.openedTimestamp
        )
    }

    /**
     * Calculates analytics metrics for email open rates.
     */
    fun computeTrackingMetrics(leads: List<RealtorLeadEntity>): EmailTrackingMetrics {
        val sentLeads = leads.filter { 
            it.status == "SENT" || it.status == "SEEN" || it.status == "REPLIED" || it.status == "CONVERTED" || it.isSeen || it.lastContactedTimestamp > 0L 
        }
        val totalSent = sentLeads.size
        val totalSeen = sentLeads.count { it.isSeen || it.status == "SEEN" || it.status == "REPLIED" || it.status == "CONVERTED" }
        val totalUnseen = (totalSent - totalSeen).coerceAtLeast(0)
        
        val openRate = if (totalSent > 0) {
            ((totalSeen.toDouble() / totalSent) * 100).roundToInt()
        } else 0

        return EmailTrackingMetrics(
            totalSent = totalSent,
            totalSeen = totalSeen,
            totalUnseen = totalUnseen,
            openRatePercentage = openRate
        )
    }

    /**
     * Calculates comparative A/B subject line performance metrics and determines winning variant.
     */
    fun computeABTestMetrics(leads: List<RealtorLeadEntity>): ABTestMetrics {
        val sentLeads = leads.filter { 
            it.status == "SENT" || it.status == "SEEN" || it.status == "REPLIED" || it.status == "CONVERTED" || it.isSeen || it.lastContactedTimestamp > 0L 
        }

        val leadsA = sentLeads.filter { it.abSubjectVariant.contains("A", ignoreCase = true) || it.abSubjectVariant.isBlank() }
        val leadsB = sentLeads.filter { it.abSubjectVariant.contains("B", ignoreCase = true) }

        val aSent = leadsA.size
        val aSeen = leadsA.count { it.isSeen || it.status == "SEEN" || it.status == "REPLIED" || it.status == "CONVERTED" }
        val aRate = if (aSent > 0) ((aSeen.toDouble() / aSent) * 100).roundToInt() else 0

        val bSent = leadsB.size
        val bSeen = leadsB.count { it.isSeen || it.status == "SEEN" || it.status == "REPLIED" || it.status == "CONVERTED" }
        val bRate = if (bSent > 0) ((bSeen.toDouble() / bSent) * 100).roundToInt() else 0

        val winner = when {
            bRate > aRate -> "Variant B"
            aRate > bRate -> "Variant A"
            else -> "Tied"
        }

        val lift = if (aRate > 0 && bRate > 0) {
            val diff = kotlin.math.abs(bRate - aRate)
            val base = kotlin.math.min(aRate, bRate)
            ((diff.toDouble() / base) * 100).roundToInt()
        } else if (bRate > aRate) {
            bRate
        } else {
            aRate
        }

        return ABTestMetrics(
            variantASentCount = aSent,
            variantASeenCount = aSeen,
            variantAOpenRate = aRate,
            variantBSentCount = bSent,
            variantBSeenCount = bSeen,
            variantBOpenRate = bRate,
            winningVariant = winner,
            liftPercentage = lift
        )
    }
}
