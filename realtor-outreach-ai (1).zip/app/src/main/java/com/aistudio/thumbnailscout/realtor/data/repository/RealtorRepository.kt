package com.aistudio.thumbnailscout.realtor.data.repository

import com.aistudio.thumbnailscout.realtor.data.UserPreferences
import com.aistudio.thumbnailscout.realtor.data.local.RealtorLeadDao
import com.aistudio.thumbnailscout.realtor.data.local.RealtorLeadEntity
import com.aistudio.thumbnailscout.realtor.data.local.SystemLogDao
import com.aistudio.thumbnailscout.realtor.data.local.SystemLogEntity
import com.aistudio.thumbnailscout.realtor.data.remote.DispatchProgressState
import com.aistudio.thumbnailscout.realtor.data.remote.DispatchScheduler
import com.aistudio.thumbnailscout.realtor.data.remote.EmailTrackingService
import com.aistudio.thumbnailscout.realtor.data.remote.GeminiScoutEngine
import com.aistudio.thumbnailscout.realtor.data.remote.LeadDiscoveryEngine
import com.aistudio.thumbnailscout.realtor.data.remote.OutreachTemplate
import com.aistudio.thumbnailscout.realtor.data.remote.PromptTemplateGenerator
import com.aistudio.thumbnailscout.realtor.data.remote.YouTubeDataApiService
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.StateFlow

class RealtorRepository(
    private val leadDao: RealtorLeadDao,
    private val logDao: SystemLogDao,
    private val preferences: UserPreferences,
    private val geminiEngine: GeminiScoutEngine,
    private val leadDiscoveryEngine: LeadDiscoveryEngine,
    private val dispatchScheduler: DispatchScheduler,
    private val youtubeService: YouTubeDataApiService = YouTubeDataApiService(leadDao, logDao, preferences, geminiEngine),
    val trackingService: EmailTrackingService = EmailTrackingService(),
    val templateGenerator: PromptTemplateGenerator = PromptTemplateGenerator()
) {
    val allLeads: Flow<List<RealtorLeadEntity>> = leadDao.getAllLeads()
    val recentLogs: Flow<List<SystemLogEntity>> = logDao.getRecentLogs()
    val leadCount: Flow<Int> = leadDao.getLeadCount()
    val outreachedCount: Flow<Int> = leadDao.getOutreachedCount()
    val repliedCount: Flow<Int> = leadDao.getRepliedCount()
    val dispatchProgress: StateFlow<DispatchProgressState> = dispatchScheduler.progressState

    suspend fun initializePreloadedLeadsIfEmpty() {
        // If DB is empty, populate initial high-priority US realtor leads
        val count = leadDao.getLeadCountList()
        if (count == 0) {
            val initialLeads = leadDiscoveryEngine.generateInitialUSRealtorLeads()
            leadDao.insertLeads(initialLeads)
            logDao.insertLog(
                SystemLogEntity(
                    title = "✨ Initial US Realtor Database Populated",
                    message = "Loaded ${initialLeads.size} active realtors with weak thumbnails and high contact priority",
                    logType = "SCAN"
                )
            )
        }
    }

    suspend fun performLiveChannelScan(searchKeyword: String) {
        val youtubeResults = youtubeService.searchAndStoreRealEstateLeads(
            queryKeyword = searchKeyword,
            maxResults = 10,
            maxSubscribersCutoff = 5000
        )
        if (youtubeResults.isEmpty()) {
            val scanned = leadDiscoveryEngine.scanNewUSRealtors(searchKeyword)
            for (lead in scanned) {
                // Run Gemini Audit & Outreach Generation for each scanned lead
                val audit = geminiEngine.analyzeChannelAndGenerateOutreach(
                    realtorName = lead.realtorName,
                    channelName = lead.channelName,
                    recentVideoTitle = lead.recentVideoTitle,
                    locationState = lead.locationState,
                    subscribers = lead.subscriberCount,
                    avgViews = lead.avgViews,
                    senderName = preferences.senderName,
                    systemPrompt = preferences.aiSystemPrompt
                )

                val enrichedLead = lead.copy(
                    currentThumbnailRatingScore = audit.thumbnailScore,
                    thumbnailImprovementNote = audit.weakPoints,
                    competitorBenchmarkComparison = audit.competitorComparison,
                    personalizedEmailSubject = audit.subjectLine,
                    personalizedEmailBody = audit.naturalEmailBody,
                    videoCommentText = audit.videoComment,
                    aiThumbnailConceptPrompt = audit.thumbnailPrompt,
                    status = "AUDITED"
                )
                leadDao.insertLead(enrichedLead)

                logDao.insertLog(
                    SystemLogEntity(
                        title = "🔎 Lead Discovered & Audited",
                        message = "Scanned ${lead.channelName} (${lead.locationState}). Thumbnail Score: ${audit.thumbnailScore}/10 [WEAK]",
                        logType = "SCAN"
                    )
                )
            }
        }
    }

    suspend fun reAnalyzeLeadWithGemini(lead: RealtorLeadEntity) {
        val audit = geminiEngine.analyzeChannelAndGenerateOutreach(
            realtorName = lead.realtorName,
            channelName = lead.channelName,
            recentVideoTitle = lead.recentVideoTitle,
            locationState = lead.locationState,
            subscribers = lead.subscriberCount,
            avgViews = lead.avgViews,
            senderName = preferences.senderName,
            systemPrompt = preferences.aiSystemPrompt
        )

        val updated = lead.copy(
            currentThumbnailRatingScore = audit.thumbnailScore,
            thumbnailImprovementNote = audit.weakPoints,
            competitorBenchmarkComparison = audit.competitorComparison,
            personalizedEmailSubject = audit.subjectLine,
            personalizedEmailBody = audit.naturalEmailBody,
            videoCommentText = audit.videoComment,
            aiThumbnailConceptPrompt = audit.thumbnailPrompt,
            status = "AUDITED"
        )
        leadDao.updateLead(updated)

        logDao.insertLog(
            SystemLogEntity(
                title = "🤖 AI Channel Audit Refreshed",
                message = "Regenerated natural human email & CTR prompt for ${lead.realtorName}",
                logType = "AUDIT"
            )
        )
    }

    suspend fun auditThumbnailWithGeminiVision(lead: RealtorLeadEntity) {
        val audit = geminiEngine.analyzeThumbnailWithVision(
            imageUrl = lead.recentThumbnailUrl,
            channelName = lead.channelName,
            recentVideoTitle = lead.recentVideoTitle,
            locationState = lead.locationState,
            realtorName = lead.realtorName,
            senderName = preferences.senderName
        )

        val updated = lead.copy(
            currentThumbnailRatingScore = audit.thumbnailScore,
            thumbnailImprovementNote = audit.weakPoints,
            competitorBenchmarkComparison = audit.competitorComparison,
            personalizedEmailSubject = audit.subjectLine,
            personalizedEmailBody = audit.naturalEmailBody,
            videoCommentText = audit.videoComment,
            aiThumbnailConceptPrompt = audit.thumbnailPrompt,
            status = "AUDITED"
        )
        leadDao.updateLead(updated)

        logDao.insertLog(
            SystemLogEntity(
                title = "🖼️ Gemini Vision Thumbnail Audit",
                message = "Vision Multimodal Audit for ${lead.channelName}: Score ${audit.thumbnailScore}/10. Actionable Critique: ${audit.weakPoints}",
                logType = "AUDIT"
            )
        )
    }

    fun startAutomatedDripDispatch(leads: List<RealtorLeadEntity>) {
        dispatchScheduler.startAutomatedDripDispatch(
            leads = leads,
            delaySeconds = preferences.dispatchDelaySeconds,
            targetTimezoneStr = preferences.targetTimezone
        )
    }

    fun scheduleWorkManagerOutreachQueue(
        leads: List<RealtorLeadEntity>,
        minAntiSpamIntervalSec: Long = 180L,
        respectBusinessHours: Boolean = true
    ) {
        dispatchScheduler.scheduleWorkManagerStaggeredQueue(
            leads = leads,
            minAntiSpamIntervalSec = minAntiSpamIntervalSec,
            respectBusinessHours = respectBusinessHours
        )
    }

    fun cancelWorkManagerQueue() {
        dispatchScheduler.cancelWorkManagerQueue()
    }

    fun launchGmailForLead(lead: RealtorLeadEntity) {
        dispatchScheduler.launchNativeGmailIntent(lead)
    }

    suspend fun simulatePixelOpenForLead(lead: RealtorLeadEntity) {
        val updated = trackingService.processPixelHit(lead)
        leadDao.updateLead(updated)
        logDao.insertLog(
            SystemLogEntity(
                title = "👁️ Pixel Open Detected [${lead.abSubjectVariant}]",
                message = "${lead.realtorName} opened email outreach (${lead.abSubjectVariant})! Subject: '${lead.personalizedEmailSubject}'. Open count: ${updated.openCount}",
                logType = "SYSTEM"
            )
        )
    }

    suspend fun applyTemplateToLead(
        lead: RealtorLeadEntity,
        templateId: String,
        preferredVariant: String = "AUTO"
    ): RealtorLeadEntity {
        val template = templateGenerator.availableTemplates.find { it.id == templateId }
            ?: templateGenerator.availableTemplates.first()
        val draft = templateGenerator.craftEmailFromTemplate(template, lead, preferences.senderName, preferredVariant)
        val updated = lead.copy(
            personalizedEmailSubject = draft.subjectLine,
            personalizedEmailBody = draft.emailBody,
            abSubjectVariant = draft.abVariantUsed
        )
        leadDao.updateLead(updated)
        logDao.insertLog(
            SystemLogEntity(
                title = "📝 A/B Template Drafted [${draft.abVariantUsed}]",
                message = "Assigned ${draft.abVariantUsed} subject line: '${draft.subjectLine}' for ${lead.realtorName}",
                logType = "AUDIT"
            )
        )
        return updated
    }

    suspend fun updateLead(lead: RealtorLeadEntity) {
        leadDao.updateLead(lead)
    }

    suspend fun deleteLead(lead: RealtorLeadEntity) {
        leadDao.deleteLead(lead)
    }

    suspend fun processVoiceCommand(command: String): String {
        return geminiEngine.processVoiceCommand(command, preferences.aiSystemPrompt)
    }

    fun getUserPreferences(): UserPreferences = preferences
}
