package com.aistudio.thumbnailscout.realtor.ui.screens

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun PinLockScreen(onUnlocked: () -> Unit) {
    var enteredPin by remember { mutableStateOf("") }
    val correctPin = "739270"
    val context = LocalContext.current

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(24.dp)
        ) {
            Text("🔒 Secure Settings", fontSize = 22.sp, style = MaterialTheme.typography.headlineMedium)
            Spacer(modifier = Modifier.height(16.dp))
            Text("Please enter your 6-digit PIN to access API & Agency controls.", fontSize = 14.sp)
            Spacer(modifier = Modifier.height(24.dp))

            OutlinedTextField(
                value = enteredPin,
                onValueChange = { enteredPin = it },
                label = { Text("Enter PIN (739270)") },
                visualTransformation = PasswordVisualTransformation(),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(16.dp))

            Button(onClick = {
                if (enteredPin == correctPin) {
                    onUnlocked()
                } else {
                    Toast.makeText(context, "Incorrect PIN! Try 739270", Toast.LENGTH_SHORT).show()
                }
            }) {
                Text("Unlock Settings")
            }
        }
    }
}
