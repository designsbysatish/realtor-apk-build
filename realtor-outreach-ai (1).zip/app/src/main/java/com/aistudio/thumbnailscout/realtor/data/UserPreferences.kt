package com.aistudio.thumbnailscout.realtor.data

import android.content.Context
import android.content.SharedPreferences

class UserPreferences(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("thumbnail_scout_prefs", Context.MODE_PRIVATE)

    var senderName: String
        get() = prefs.getString("sender_name", "Rahul (Thumbnail Specialist)") ?: "Rahul (Thumbnail Specialist)"
        set(value) = prefs.edit().putString("sender_name", value).apply()

    var userEmail: String
        get() = prefs.getString("user_email", "designer@realtorthumbnails.com") ?: "designer@realtorthumbnails.com"
        set(value) = prefs.edit().putString("user_email", value).apply()

    var youtubeApiKey: String
        get() = prefs.getString("youtube_api_key", "") ?: ""
        set(value) = prefs.edit().putString("youtube_api_key", value).apply()

    var gmailApiKey: String
        get() = prefs.getString("gmail_api_key", "") ?: ""
        set(value) = prefs.edit().putString("gmail_api_key", value).apply()

    var dispatchDelaySeconds: Int
        get() = prefs.getInt("dispatch_delay_sec", 5)
        set(value) = prefs.edit().putInt("dispatch_delay_sec", value).apply()

    var targetTimezone: String
        get() = prefs.getString("target_timezone", "US/Eastern") ?: "US/Eastern"
        set(value) = prefs.edit().putString("target_timezone", value).apply()

    var autoAgentEnabled: Boolean
        get() = prefs.getBoolean("auto_agent_enabled", false)
        set(value) = prefs.edit().putBoolean("auto_agent_enabled", value).apply()

    var voiceFeedbackEnabled: Boolean
        get() = prefs.getBoolean("voice_feedback_enabled", true)
        set(value) = prefs.edit().putBoolean("voice_feedback_enabled", value).apply()

    var dailyOutreachLimit: Int
        get() = prefs.getInt("daily_limit", 20)
        set(value) = prefs.edit().putInt("daily_limit", value).apply()

    var niche: String
        get() = prefs.getString("niche", "Real Estate") ?: "Real Estate"
        set(value) = prefs.edit().putString("niche", value).apply()

    var themeMode: String // "DARK", "LIGHT", "SYSTEM"
        get() = prefs.getString("theme_mode", "DARK") ?: "DARK"
        set(value) = prefs.edit().putString("theme_mode", value).apply()

    var isDemoMode: Boolean
        get() = prefs.getBoolean("is_demo_mode", false)
        set(value) = prefs.edit().putBoolean("is_demo_mode", value).apply()

    var aiSystemPrompt: String
        get() = prefs.getString("ai_system_prompt", "Target creators with 50-50k subscribers. Focus on weak thumbnails.") ?: "Target creators with 50-50k subscribers. Focus on weak thumbnails."
        set(value) = prefs.edit().putString("ai_system_prompt", value).apply()
}
