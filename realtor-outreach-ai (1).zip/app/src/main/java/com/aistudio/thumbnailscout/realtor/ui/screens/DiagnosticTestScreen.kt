package com.aistudio.thumbnailscout.realtor.ui.screens

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Link
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aistudio.thumbnailscout.realtor.data.UserPreferences
import com.aistudio.thumbnailscout.realtor.data.local.AppDatabase
import com.aistudio.thumbnailscout.realtor.ui.theme.GoldAccent
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun DiagnosticTestScreen(preferences: UserPreferences) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    
    var testLogs by remember { mutableStateOf("System Diagnostics Ready. Click buttons below to test components.\n") }
    var isTesting by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            "🔍 System Health & Business Tools",
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            color = GoldAccent
        )

        Text(
            "Monitor app performance and access curated tools to grow your thumbnail business.",
            fontSize = 13.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        // Diagnostic Buttons
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DiagnosticButton(
                title = "API & Config",
                icon = Icons.Default.Info,
                modifier = Modifier.weight(1f)
            ) {
                var report = "--- CONFIGURATION CHECK ---\n"
                val youtubeKey = com.aistudio.thumbnailscout.realtor.utils.AppSettingsManager.youtubeApiKey
                val gmailPass = com.aistudio.thumbnailscout.realtor.utils.AppSettingsManager.gmailAppPass
                
                report += if (youtubeKey.isNotBlank()) "✅ YouTube Data API: Connected\n" else "❌ YouTube API: Missing!\n"
                report += if (gmailPass.isNotBlank()) "✅ Gmail App Pass: Configured\n" else "⚠️ Gmail App Pass: Missing!\n"
                report += "🎨 Theme: ${preferences.themeMode}\n"
                report += "🚀 Demo Mode: ${if (preferences.isDemoMode) "ON" else "OFF"}\n"
                testLogs = report + "\n" + testLogs
            }

            DiagnosticButton(
                title = "DB Health",
                icon = Icons.Default.Build,
                modifier = Modifier.weight(1f)
            ) {
                scope.launch(Dispatchers.IO) {
                    try {
                        val db = AppDatabase.getInstance(context)
                        val count = db.realtorLeadDao().getLeadCountList()
                        withContext(Dispatchers.Main) {
                            testLogs = "✅ Database Check: $count leads found in local storage.\n\n" + testLogs
                        }
                    } catch (e: Exception) {
                        withContext(Dispatchers.Main) {
                            testLogs = "❌ DB Error: ${e.message}\n\n" + testLogs
                        }
                    }
                }
            }
        }

        Text("📋 Live Health Logs", fontWeight = FontWeight.Bold, fontSize = 14.sp)
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .height(150.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
        ) {
            Box(modifier = Modifier.padding(12.dp).fillMaxSize()) {
                Text(text = testLogs, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface)
            }
        }

        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))

        Text("🚀 Free Business Growth Tools", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = GoldAccent)

        BusinessToolCard(
            title = "Canva (Free Design Templates)",
            description = "Start with pro-level templates for real estate thumbnails.",
            url = "https://www.canva.com/templates/s/real-estate-youtube-thumbnail/"
        )

        BusinessToolCard(
            title = "Remove.bg (Auto Background Remover)",
            description = "Remove background from realtor faces instantly for better contrast.",
            url = "https://www.remove.bg/"
        )

        BusinessToolCard(
            title = "Google Trends (Targeting)",
            description = "Find which real estate markets are currently trending in the US.",
            url = "https://trends.google.com/trends/explore?geo=US&q=Real%20Estate"
        )

        BusinessToolCard(
            title = "TubeBuddy (CTR Optimizer)",
            description = "Check high-performing keywords for your outreach strategies.",
            url = "https://www.tubebuddy.com/"
        )
        
        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
fun DiagnosticButton(title: String, icon: ImageVector, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = modifier.height(50.dp),
        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(12.dp),
        elevation = ButtonDefaults.buttonElevation(defaultElevation = 2.dp)
    ) {
        Icon(icon, contentDescription = null, modifier = Modifier.size(16.dp), tint = GoldAccent)
        Spacer(modifier = Modifier.width(6.dp))
        Text(title, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun BusinessToolCard(title: String, description: String, url: String) {
    val context = LocalContext.current
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text(description, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            IconButton(onClick = {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                context.startActivity(intent)
            }) {
                Icon(Icons.Default.Link, contentDescription = "Open Link", tint = GoldAccent)
            }
        }
    }
}
