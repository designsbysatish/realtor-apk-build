package com.aistudio.thumbnailscout.realtor.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "system_logs")
data class SystemLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val message: String,
    val logType: String, // "SCAN", "AUDIT", "DISPATCH", "SYSTEM", "SUCCESS", "WARN"
    val timestamp: Long = System.currentTimeMillis()
)
