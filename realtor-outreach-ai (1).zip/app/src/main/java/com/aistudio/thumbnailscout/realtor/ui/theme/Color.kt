package com.aistudio.thumbnailscout.realtor.ui.theme

import androidx.compose.ui.graphics.Color

val DeepSlateBackground = Color(0xFF0F172A)
val DarkNavySurface = Color(0xFF1E293B)
val DarkNavySurfaceVariant = Color(0xFF334155)

val GoldAccent = Color(0xFFF59E0B)
val GoldAccentLight = Color(0xFFFCD34D)

val EmeraldSuccess = Color(0xFF10B981)
val CoralCritical = Color(0xFFEF4444)
val AmberWarning = Color(0xFFF59E0B)

val TextPrimaryLight = Color(0xFFF8FAFC)
val TextSecondaryLight = Color(0xFF94A3B8)
val BorderStroke = Color(0xFF475569)

// Light Mode Colors
val LightBackground = Color(0xFFF1F5F9)
val LightSurface = Color(0xFFFFFFFF)
val TextPrimaryDark = Color(0xFF0F172A)
val TextSecondaryDark = Color(0xFF475569)
