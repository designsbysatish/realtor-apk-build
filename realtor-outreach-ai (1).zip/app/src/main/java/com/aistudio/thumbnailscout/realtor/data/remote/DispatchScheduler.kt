package com.aistudio.thumbnailscout.realtor.data.remote

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.work.Constraints
import androidx.work.Data
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import com.aistudio.thumbnailscout.realtor.data.local.RealtorLeadDao
import com.aistudio.thumbnailscout.realtor.data.local.RealtorLeadEntity
import com.aistudio.thumbnailscout.realtor.data.local.SystemLogDao
import com.aistudio.thumbnailscout.realtor.data.local.SystemLogEntity
import com.aistudio.thumbnailscout.realtor.worker.EmailDispatchWorker
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.TimeUnit

data class DispatchProgressState(
    val isRunning: Boolean = false,
    val isWorkManagerActive: Boolean = false,
    val totalInQueue: Int = 0,
    val processedCount: Int = 0,
    val currentTargetName: String = "",
    val statusMessage: String = "Queue Idle"
)

class DispatchScheduler(
    private val context: Context,
    private val leadDao: RealtorLeadDao,
    private val logDao: SystemLogDao,
    private val trackingService: EmailTrackingService = EmailTrackingService()
) {
    private val _progressState = MutableStateFlow(DispatchProgressState())
    val progressState: StateFlow<DispatchProgressState> = _progressState.asStateFlow()

    private val scope = CoroutineScope(Dispatchers.IO)

    /**
     * Schedules automated background jobs via WorkManager with timezone awareness
     * and anti-spam staggered delays.
     */
    fun scheduleWorkManagerStaggeredQueue(
        leads: List<RealtorLeadEntity>,
        minAntiSpamIntervalSec: Long = 180L,
        respectBusinessHours: Boolean = true
    ) {
        if (leads.isEmpty()) return

        val workManager = WorkManager.getInstance(context)
        
        // Network connectivity requirement
        val constraints = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .build()

        var enqueuedCount = 0

        leads.forEachIndexed { index, lead ->
            val targetTz = TimezoneUtils.getTimezoneForLocation(lead.locationState)
            val delaySec = TimezoneUtils.calculateTimezoneStaggeredDelaySeconds(
                locationState = lead.locationState,
                staggerIndex = index,
                minAntiSpamIntervalSec = minAntiSpamIntervalSec,
                respectBusinessHours = respectBusinessHours
            )

            val inputData = Data.Builder()
                .putLong(EmailDispatchWorker.KEY_LEAD_ID, lead.id)
                .putString(EmailDispatchWorker.KEY_TARGET_TIMEZONE, targetTz)
                .putLong(EmailDispatchWorker.KEY_ANTI_SPAM_INTERVAL_SEC, minAntiSpamIntervalSec)
                .build()

            val workRequest = OneTimeWorkRequestBuilder<EmailDispatchWorker>()
                .setConstraints(constraints)
                .setInitialDelay(delaySec, TimeUnit.SECONDS)
                .setInputData(inputData)
                .addTag(EmailDispatchWorker.WORK_TAG_OUTREACH)
                .build()

            workManager.enqueue(workRequest)
            enqueuedCount++
        }

        _progressState.value = DispatchProgressState(
            isRunning = true,
            isWorkManagerActive = true,
            totalInQueue = enqueuedCount,
            processedCount = 0,
            currentTargetName = "${leads.firstOrNull()?.realtorName} (First in WorkManager queue)",
            statusMessage = "⏱️ $enqueuedCount jobs queued in WorkManager! Staggered across US timezones."
        )

        scope.launch {
            logDao.insertLog(
                SystemLogEntity(
                    title = "⚡ WorkManager Queue Initiated",
                    message = "Scheduled $enqueuedCount staggered background dispatch jobs. Anti-spam interval: ${minAntiSpamIntervalSec}s, Business hours mode: $respectBusinessHours.",
                    logType = "DISPATCH"
                )
            )
        }
    }

    /**
     * Cancels all scheduled WorkManager dispatch jobs.
     */
    fun cancelWorkManagerQueue() {
        try {
            WorkManager.getInstance(context).cancelAllWorkByTag(EmailDispatchWorker.WORK_TAG_OUTREACH)
            _progressState.value = DispatchProgressState(
                isRunning = false,
                isWorkManagerActive = false,
                statusMessage = "🛑 WorkManager job queue cancelled."
            )
            scope.launch {
                logDao.insertLog(
                    SystemLogEntity(
                        title = "🛑 Queue Cancelled",
                        message = "User cancelled all pending WorkManager email dispatch jobs.",
                        logType = "WARNING"
                    )
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun startAutomatedDripDispatch(
        leads: List<RealtorLeadEntity>,
        delaySeconds: Int = 5,
        targetTimezoneStr: String = "US/Eastern"
    ) {
        if (_progressState.value.isRunning) return

        scope.launch {
            _progressState.value = DispatchProgressState(
                isRunning = true,
                totalInQueue = leads.size,
                processedCount = 0,
                currentTargetName = "",
                statusMessage = "Starting timezone-adjusted automated dispatch with tracking pixel injection..."
            )

            logDao.insertLog(
                SystemLogEntity(
                    title = "🚀 Queue Started",
                    message = "Automated drip sequence initiated for ${leads.size} US Realtors with tracking pixel embedding.",
                    logType = "DISPATCH"
                )
            )

            for ((index, lead) in leads.withIndex()) {
                val formattedTime = getTimeInZone(targetTimezoneStr)

                _progressState.value = DispatchProgressState(
                    isRunning = true,
                    totalInQueue = leads.size,
                    processedCount = index + 1,
                    currentTargetName = "${lead.realtorName} (${lead.locationState})",
                    statusMessage = "Injecting pixel & sending outreach to ${lead.realtorName}... [$formattedTime $targetTimezoneStr]"
                )

                // Generate Tracking Pixel
                val pixelInfo = trackingService.generateTrackingPixel(lead.id)
                val bodyWithPixel = trackingService.injectTrackingPixel(lead.personalizedEmailBody, pixelInfo)

                delay(delaySeconds * 1000L)

                // Update Lead Status to "SENT" with pixel ID and initial isSeen = false
                val updatedLead = lead.copy(
                    status = "SENT",
                    personalizedEmailBody = bodyWithPixel,
                    trackingPixelId = pixelInfo.pixelId,
                    isSeen = false,
                    lastContactedTimestamp = System.currentTimeMillis()
                )
                leadDao.updateLead(updatedLead)

                logDao.insertLog(
                    SystemLogEntity(
                        title = "✉️ Email Sent (Pixel Embedded)",
                        message = "Delivered to ${lead.realtorName} (${lead.email}) [Pixel ID: ${pixelInfo.pixelId}]",
                        logType = "SUCCESS"
                    )
                )

                // Simulate pixel trigger open event for a portion of leads
                if (index % 2 == 0) {
                    delay(1500L)
                    val seenLead = trackingService.processPixelHit(updatedLead)
                    leadDao.updateLead(seenLead)
                    logDao.insertLog(
                        SystemLogEntity(
                            title = "👁️ Tracking Pixel Fired (Seen)",
                            message = "${lead.realtorName} opened email outreach from ${lead.locationState} [Pixel: ${pixelInfo.pixelId}]",
                            logType = "SYSTEM"
                        )
                    )
                }
            }

            _progressState.value = DispatchProgressState(
                isRunning = false,
                totalInQueue = leads.size,
                processedCount = leads.size,
                currentTargetName = "",
                statusMessage = "✅ All outreach dispatches completed with tracking active!"
            )

            logDao.insertLog(
                SystemLogEntity(
                    title = "🎉 Dispatch Batch Complete",
                    message = "Successfully dispatched tracked outreach emails to all ${leads.size} active realtors.",
                    logType = "SUCCESS"
                )
            )
        }
    }

    fun launchNativeGmailIntent(lead: RealtorLeadEntity) {
        try {
            val pixelInfo = trackingService.generateTrackingPixel(lead.id)
            val bodyWithPixel = trackingService.injectTrackingPixel(lead.personalizedEmailBody, pixelInfo)

            val intent = Intent(Intent.ACTION_SENDTO).apply {
                data = Uri.parse("mailto:${lead.email}")
                putExtra(Intent.EXTRA_SUBJECT, lead.personalizedEmailSubject)
                putExtra(Intent.EXTRA_TEXT, bodyWithPixel)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)

            scope.launch {
                val updated = lead.copy(
                    status = "SENT",
                    personalizedEmailBody = bodyWithPixel,
                    trackingPixelId = pixelInfo.pixelId,
                    isSeen = false,
                    lastContactedTimestamp = System.currentTimeMillis()
                )
                leadDao.updateLead(updated)
                logDao.insertLog(
                    SystemLogEntity(
                        title = "✉️ External Mail Launched",
                        message = "Opened Gmail client for ${lead.realtorName} (${lead.email}) [Pixel: ${pixelInfo.pixelId}]",
                        logType = "DISPATCH"
                    )
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun getTimeInZone(tzId: String): String {
        return try {
            val sdf = SimpleDateFormat("hh:mm a", Locale.US)
            sdf.timeZone = TimeZone.getTimeZone(tzId)
            sdf.format(Date())
        } catch (e: Exception) {
            "10:00 AM"
        }
    }
}
