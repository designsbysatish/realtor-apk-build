package com.aistudio.thumbnailscout.realtor.utils

import android.content.Context
import android.widget.Toast
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Properties
import javax.mail.*
import javax.mail.internet.InternetAddress
import javax.mail.internet.MimeMessage

object GmailOutreachManager {

    // Send Professional Outreach Email to a Client
    suspend fun sendOutreachEmail(
        context: Context,
        clientEmail: String,
        clientChannelName: String,
        appPassword: String
    ): Boolean = withContext(Dispatchers.IO) {
        try {
            val senderEmail = AppSettingsManager.gmailUser.ifEmpty { "satishdesigns.work@gmail.com" }
            val senderName = AppSettingsManager.designerName
            val portfolioUrl = AppSettingsManager.portfolioUrl
            val paypalUrl = AppSettingsManager.paypalUrl
            val pricePerThumbnail = AppSettingsManager.pricePerThumbnail
            val revisionPolicy = AppSettingsManager.revisionPolicy

            val host = "smtp.gmail.com"
            val props = Properties().apply {
                put("mail.smtp.auth", "true")
                put("mail.smtp.starttls.enable", "true")
                put("mail.smtp.host", host)
                put("mail.smtp.port", "587")
            }

            val session = Session.getInstance(props, object : Authenticator() {
                override fun getPasswordAuthentication(): PasswordAuthentication {
                    return PasswordAuthentication(senderEmail, appPassword)
                }
            })

            val message = MimeMessage(session).apply {
                setFrom(InternetAddress(senderEmail, senderName))
                setRecipients(Message.RecipientType.TO, InternetAddress.parse(clientEmail))
                subject = "Quick question about your thumbnails on $clientChannelName"
                
                val emailBody = """
                    Hi $clientChannelName Team,
                    
                    I was checking out your recent videos and noticed your content is fantastic, but your thumbnails could use a higher CTR punch to bring in more views.
                    
                    I have designed a high-converting sample specifically for your channel style. You can check my previous work here:
                    📁 $portfolioUrl
                    
                    My offer is simple: 
                    • High-CTR Professional Thumbnail
                    • Only $pricePerThumbnail per thumbnail with $revisionPolicy
                    • Fast 24-hour delivery
                    
                    If interested, just reply to this email or complete the secure payment via PayPal to start:
                    💳 $paypalUrl
                    
                    Best regards,
                    $senderName
                    Thumbnail Specialist
                    ($senderEmail)
                """.trimIndent()
                
                setText(emailBody)
            }

            Transport.send(message)
            withContext(Dispatchers.Main) {
                Toast.makeText(context, "✅ Outreach email sent successfully from $senderEmail", Toast.LENGTH_SHORT).show()
            }
            true
        } catch (e: Exception) {
            e.printStackTrace()
            withContext(Dispatchers.Main) {
                Toast.makeText(context, "❌ Error sending email: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
            }
            false
        }
    }

    // Send Finished Thumbnail Draft & PayPal Link when Client Orders
    suspend fun sendThumbnailDelivery(
        context: Context,
        clientEmail: String,
        clientName: String,
        optionNumber: Int,
        appPassword: String
    ): Boolean = withContext(Dispatchers.IO) {
        try {
            val senderEmail = AppSettingsManager.gmailUser.ifEmpty { "satishdesigns.work@gmail.com" }
            val senderName = AppSettingsManager.designerName
            val paypalUrl = AppSettingsManager.paypalUrl
            val pricePerThumbnail = AppSettingsManager.pricePerThumbnail

            val host = "smtp.gmail.com"
            val props = Properties().apply {
                put("mail.smtp.auth", "true")
                put("mail.smtp.starttls.enable", "true")
                put("mail.smtp.host", host)
                put("mail.smtp.port", "587")
            }

            val session = Session.getInstance(props, object : Authenticator() {
                override fun getPasswordAuthentication(): PasswordAuthentication {
                    return PasswordAuthentication(senderEmail, appPassword)
                }
            })

            val message = MimeMessage(session).apply {
                setFrom(InternetAddress(senderEmail, senderName))
                setRecipients(Message.RecipientType.TO, InternetAddress.parse(clientEmail))
                subject = "Your Thumbnail Draft (Option $optionNumber) is Ready! - $senderName"
                
                val deliveryBody = """
                    Hi $clientName,
                    
                    I have finalized Option $optionNumber based on your requirements and high-CTR layout analysis.
                    
                    To unlock the full-resolution source file and complete your order, please process the $pricePerThumbnail payment securely via PayPal:
                    💳 $paypalUrl
                    
                    Once confirmed, I will dispatch the final asset immediately along with unlimited revisions support!
                    
                    Best regards,
                    $senderName
                    ($senderEmail)
                """.trimIndent()
                
                setText(deliveryBody)
            }

            Transport.send(message)
            withContext(Dispatchers.Main) {
                Toast.makeText(context, "✅ Delivery email sent from $senderEmail", Toast.LENGTH_SHORT).show()
            }
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }
}
