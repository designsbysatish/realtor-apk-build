package com.aistudio.thumbnailscout.realtor

import android.app.Application
import androidx.work.Constraints
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.aistudio.thumbnailscout.realtor.worker.OutreachWorker
import com.aistudio.thumbnailscout.realtor.utils.AppInstance
import java.util.concurrent.TimeUnit

class ThumbnailScoutApp : Application() {
    override fun onCreate() {
        super.onCreate()
        AppInstance.context = this
        
        // 24/7 Background Agent Background Task Setup
        val constraints = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .build()

        val outreachRequest = PeriodicWorkRequestBuilder<OutreachWorker>(
            15, TimeUnit.MINUTES // Har 15 minute mein background task check karega
        ).setConstraints(constraints).build()

        WorkManager.getInstance(this).enqueue(outreachRequest)
    }
}
