package com.aistudio.thumbnailscout.realtor.ui.screens

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aistudio.thumbnailscout.realtor.utils.AppSettingsManager
import com.aistudio.thumbnailscout.realtor.utils.GmailOutreachManager
import kotlinx.coroutines.launch

@Composable
fun ClientOrderStudioScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    
    // Simulated Incoming Client Order data from Gmail
    var clientName by remember { mutableStateOf("John Broker (USA)") }
    var clientEmail by remember { mutableStateOf("john.realtor@example.com") }
    var clientInstructions by remember { mutableStateOf("Text: 'Top 3 Florida Homes for Sale'. Attached 2 photos of my face.") }
    
    // AI Generated Options
    var selectedOption by remember { mutableStateOf(1) }
    val portfolioLink = AppSettingsManager.portfolioUrl
    val paypalLink = AppSettingsManager.paypalUrl

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("📥 AI Client Order & Review Studio", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        Text("Client ke email, photos aur instructions yahan analyze hote hain.", fontSize = 12.sp)

        // Incoming Order Details Card
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("👤 Client: $clientName ($clientEmail)", fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(4.dp))
                Text("📝 Client Instructions & Text: $clientInstructions")
                Spacer(modifier = Modifier.height(4.dp))
                Text("🖼️ Photos Received: 2 Face Cutouts Attached", color = MaterialTheme.colorScheme.secondary, fontWeight = FontWeight.Medium)
            }
        }

        Spacer(modifier = Modifier.height(4.dp))
        Text("🎨 AI Generated Thumbnail Options (Select 1 to Send):", fontWeight = FontWeight.Bold, fontSize = 15.sp)

        // Option 1
        Card(
            colors = CardDefaults.cardColors(containerColor = if (selectedOption == 1) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface),
            modifier = Modifier.fillMaxWidth(),
            onClick = { selectedOption = 1 }
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Option 1: High CTR Bold Text & Face", fontWeight = FontWeight.Bold)
                    RadioButton(selected = selectedOption == 1, onClick = { selectedOption = 1 })
                }
                Text("Style: Bright yellow background, cutout face with shocked expression, clean readable font.")
            }
        }

        // Option 2
        Card(
            colors = CardDefaults.cardColors(containerColor = if (selectedOption == 2) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface),
            modifier = Modifier.fillMaxWidth(),
            onClick = { selectedOption = 2 }
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Option 2: Luxury Real Estate Theme", fontWeight = FontWeight.Bold)
                    RadioButton(selected = selectedOption == 2, onClick = { selectedOption = 2 })
                }
                Text("Style: Moody luxury house background, professional dark overlay, minimalist text.")
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Review & Dispatch Action
        Button(
            onClick = {
                val pass = AppSettingsManager.gmailAppPass
                
                if (pass.isBlank()) {
                    Toast.makeText(context, "Pehle Settings mein Gmail credentials daalein!", Toast.LENGTH_SHORT).show()
                } else {
                    scope.launch {
                        val success = GmailOutreachManager.sendThumbnailDelivery(
                            context = context,
                            clientEmail = clientEmail,
                            clientName = clientName,
                            optionNumber = selectedOption,
                            appPassword = pass
                        )
                        if (success) {
                            Toast.makeText(context, "✅ Selected Option $selectedOption sent to client via Gmail!", Toast.LENGTH_LONG).show()
                        }
                    }
                }
            },
            modifier = Modifier.fillMaxWidth().height(50.dp)
        ) {
            Text("🚀 Approve & Send Selected Thumbnail to Client", fontSize = 15.sp)
        }
    }
}
