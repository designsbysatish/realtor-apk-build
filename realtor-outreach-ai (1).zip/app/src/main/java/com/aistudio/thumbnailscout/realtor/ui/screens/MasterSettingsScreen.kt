package com.aistudio.thumbnailscout.realtor.ui.screens

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aistudio.thumbnailscout.realtor.utils.AppSettingsManager

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MasterSettingsScreen() {
    val context = LocalContext.current
    
    // State variables linked with AppSettingsManager
    var designerName by remember { mutableStateOf(AppSettingsManager.designerName) }
    var designerEmail by remember { mutableStateOf(AppSettingsManager.designerEmail) }
    var targetNiche by remember { mutableStateOf(AppSettingsManager.targetNiche) }
    var targetCountry by remember { mutableStateOf(AppSettingsManager.targetCountry) }
    
    var pricePerThumb by remember { mutableStateOf(AppSettingsManager.pricePerThumbnail) }
    var revisionPol by remember { mutableStateOf(AppSettingsManager.revisionPolicy) }
    var portfolio by remember { mutableStateOf(AppSettingsManager.portfolioUrl) }
    var paypal by remember { mutableStateOf(AppSettingsManager.paypalUrl) }
    
    var geminiKey by remember { mutableStateOf(AppSettingsManager.geminiApiKey) }
    var youtubeKey by remember { mutableStateOf(AppSettingsManager.youtubeApiKey) }
    var gmailUser by remember { mutableStateOf(AppSettingsManager.gmailUser) }
    var gmailPass by remember { mutableStateOf(AppSettingsManager.gmailAppPass) }
    
    var openAiKey by remember { mutableStateOf(AppSettingsManager.openAiApiKey) }
    var deepSeekKey by remember { mutableStateOf(AppSettingsManager.deepSeekApiKey) }
    
    var dailyTarget by remember { mutableStateOf(AppSettingsManager.dailyTargetOutreach.toString()) }
    var monthlyGoal by remember { mutableStateOf(AppSettingsManager.monthlyGoalUsd.toString()) }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("⚙️ Master App & Agency Settings") })
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text("Yahan se aap ya koi bhi user is app ko apni marzi ke hisab se poori tarah customize kar sakta hai.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)

            // 1. Profile Section
            Text("👤 Designer & Niche Profile", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            OutlinedTextField(value = designerName, onValueChange = { designerName = it }, label = { Text("Designer / Sender Name") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = designerEmail, onValueChange = { designerEmail = it }, label = { Text("Sender Email Address") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = targetNiche, onValueChange = { targetNiche = it }, label = { Text("Target Niche (e.g., Real Estate, Gaming)") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = targetCountry, onValueChange = { targetCountry = it }, label = { Text("Target Country Code (US, UK, CA)") }, modifier = Modifier.fillMaxWidth())

            HorizontalDivider()

            // 2. Business & Offer Section
            Text("💼 Business Offer & Links", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            OutlinedTextField(value = pricePerThumb, onValueChange = { pricePerThumb = it }, label = { Text("Price per Thumbnail (e.g., $10)") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = revisionPol, onValueChange = { revisionPol = it }, label = { Text("Revision Policy (e.g., Unlimited Revisions)") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = portfolio, onValueChange = { portfolio = it }, label = { Text("Portfolio URL (e.g., tinyurl.com/...)") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = paypal, onValueChange = { paypal = it }, label = { Text("PayPal Link (e.g., paypal.me/...)") }, modifier = Modifier.fillMaxWidth())

            HorizontalDivider()

            // 3. Core API Keys
            Text("🔑 Core API & Gmail Configurations", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            OutlinedTextField(value = geminiKey, onValueChange = { geminiKey = it }, label = { Text("Gemini AI API Key") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = youtubeKey, onValueChange = { youtubeKey = it }, label = { Text("YouTube Data API v3 Key") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = gmailUser, onValueChange = { gmailUser = it }, label = { Text("Gmail Address for Outreach") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = gmailPass, onValueChange = { gmailPass = it }, label = { Text("Gmail 16-Digit App Password") }, modifier = Modifier.fillMaxWidth())

            HorizontalDivider()

            // 4. Future / Optional AI Models
            Text("🚀 Optional AI Models (Future Slots)", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)
            OutlinedTextField(value = openAiKey, onValueChange = { openAiKey = it }, label = { Text("OpenAI / ChatGPT API Key") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = deepSeekKey, onValueChange = { deepSeekKey = it }, label = { Text("DeepSeek API Key") }, modifier = Modifier.fillMaxWidth())

            HorizontalDivider()

            // 5. AI Boss Target Settings
            Text("🎯 AI Strict Boss & Growth Targets", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.error)
            OutlinedTextField(value = dailyTarget, onValueChange = { dailyTarget = it }, label = { Text("Daily Outreach Target Count") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = monthlyGoal, onValueChange = { monthlyGoal = it }, label = { Text("Monthly Earnings Goal ($ USD)") }, modifier = Modifier.fillMaxWidth())

            Spacer(modifier = Modifier.height(8.dp))

            Button(
                onClick = {
                    AppSettingsManager.designerName = designerName
                    AppSettingsManager.designerEmail = designerEmail
                    AppSettingsManager.targetNiche = targetNiche
                    AppSettingsManager.targetCountry = targetCountry
                    AppSettingsManager.pricePerThumbnail = pricePerThumb
                    AppSettingsManager.revisionPolicy = revisionPol
                    AppSettingsManager.portfolioUrl = portfolio
                    AppSettingsManager.paypalUrl = paypal
                    AppSettingsManager.geminiApiKey = geminiKey
                    AppSettingsManager.youtubeApiKey = youtubeKey
                    AppSettingsManager.gmailUser = gmailUser
                    AppSettingsManager.gmailAppPass = gmailPass
                    AppSettingsManager.openAiApiKey = openAiKey
                    AppSettingsManager.deepSeekApiKey = deepSeekKey
                    AppSettingsManager.dailyTargetOutreach = dailyTarget.toIntOrNull() ?: 20
                    AppSettingsManager.monthlyGoalUsd = monthlyGoal.toIntOrNull() ?: 1500

                    Toast.makeText(context, "✅ All Master Settings Saved Successfully!", Toast.LENGTH_SHORT).show()
                },
                modifier = Modifier.fillMaxWidth().height(55.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
            ) {
                Text("💾 Save All Master Settings", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}
