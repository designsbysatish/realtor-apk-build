package com.aistudio.thumbnailscout.realtor.data.remote

import android.graphics.BitmapFactory
import android.util.Log
import com.aistudio.thumbnailscout.realtor.BuildConfig
import com.google.ai.client.generativeai.GenerativeModel
import com.google.ai.client.generativeai.type.content
import com.google.ai.client.generativeai.type.generationConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class GeneratedAuditResult(
    val thumbnailScore: Int, // 1 to 10
    val weakPoints: String,
    val competitorComparison: String,
    val subjectLine: String,
    val naturalEmailBody: String,
    val videoComment: String,
    val ctrHookIdea: String,
    val thumbnailPrompt: String
)

class GeminiScoutEngine {

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    private fun getGenerativeModel(modelName: String = "gemini-1.5-flash"): GenerativeModel? {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isNullOrEmpty() || apiKey == "MY_GEMINI_API_KEY") return null
        
        return GenerativeModel(
            modelName = modelName,
            apiKey = apiKey,
            generationConfig = generationConfig {
                responseMimeType = "application/json"
            }
        )
    }

    suspend fun analyzeChannelAndGenerateOutreach(
        realtorName: String,
        channelName: String,
        recentVideoTitle: String,
        locationState: String,
        subscribers: Int,
        avgViews: Int,
        senderName: String,
        systemPrompt: String = ""
    ): GeneratedAuditResult = withContext(Dispatchers.IO) {
        try {
            val model = getGenerativeModel()
            if (model != null) {
                val promptText = """
                    You are an expert YouTube Thumbnail Strategist helping a thumbnail designer outreach to a US Real Estate agent / Realtor.
                    
                    USER SYSTEM INSTRUCTIONS (Follow these strictly): $systemPrompt
                    
                    Realtor Details:
                    - Name: $realtorName
                    - Channel Name: $channelName
                    - Recent Video: "$recentVideoTitle"
                    - Location: $locationState
                    - Subscribers: $subscribers, Avg Views: $avgViews
                    - Designer (Sender) Name: $senderName
                    
                    TASK: Analyze this realtor's video and thumbnail weaknesses, then write a 100% natural, human, non-robotic outreach email and video comment.
                    
                    Guidelines for Outreach Email:
                    - DO NOT sound like an AI template, corporate bot, or spammer.
                    - Speak in a natural, casual, respectful tone like a fellow real estate video fan / designer.
                    - Mention something specific about their video "$recentVideoTitle" or their market ($locationState).
                    - Point out gently why the current thumbnail might be losing clicks (e.g. text too small on mobile, lack of visual contrast, missing strong emotional hook or price callout).
                    - Offer to send a FREE custom redesigned thumbnail mockup that you ALREADY drafted specifically for their video, with ZERO cost or obligation ("I already designed a concept thumbnail for your recent video. If you're open to it, I can send it over for free!").
                    - Subject line must be punchy, curiosity-inducing, and under 7 words (e.g., "quick thumbnail idea for $channelName", "loved your $locationState tour (+ free thumbnail idea)").
                    
                    Guidelines for Video Comment:
                    - Short, genuine, 100% natural compliment on their video content. Absolutely NO links or spammy promo words.
                    
                    Format your response strictly as JSON with keys:
                    {
                      "thumbnailScore": 2,
                      "weakPoints": "<2 sentence critique>",
                      "competitorComparison": "<Comparison with top US real estate channels like Serhant>",
                      "subjectLine": "<Catchy subject line>",
                      "naturalEmailBody": "<The complete personalized email text>",
                      "videoComment": "<Natural YouTube video comment>",
                      "ctrHookIdea": "<CTR text overlay idea>",
                      "thumbnailPrompt": "<Midjourney prompt>"
                    }
                """.trimIndent()

                val response = model.generateContent(promptText)
                val text = response.text
                if (!text.isNullOrEmpty()) {
                    return@withContext parseJsonResponse(text, realtorName, channelName, recentVideoTitle, locationState, senderName)
                }
            }
            generateFallbackAudit(realtorName, channelName, recentVideoTitle, locationState, senderName)
        } catch (e: Exception) {
            Log.e("GeminiScoutEngine", "Error generating outreach", e)
            generateFallbackAudit(realtorName, channelName, recentVideoTitle, locationState, senderName)
        }
    }

    suspend fun analyzeThumbnailWithVision(
        imageUrl: String,
        channelName: String,
        recentVideoTitle: String,
        locationState: String,
        realtorName: String,
        senderName: String
    ): GeneratedAuditResult = withContext(Dispatchers.IO) {
        try {
            val model = getGenerativeModel()
            val bitmap = downloadImageAsBitmap(imageUrl)

            if (model != null && bitmap != null) {
                val promptText = """
                    You are a top YouTube Thumbnail Strategist analyzing an actual thumbnail image for a real estate channel.
                    
                    Channel: $channelName
                    Video Title: "$recentVideoTitle"
                    Location: $locationState
                    Realtor: $realtorName
                    
                    TASK: Perform a visual audit of the provided thumbnail image.
                    Evaluate:
                    1. Text contrast & legibility on mobile screens (is text readable in YouTube dark mode?).
                    2. Subject framing & emotional hook (face visibility, lighting, house angle).
                    3. Overall CTR potential out of 10 (1 = very poor/unclickable, 10 = world-class).
                    
                    Provide specific actionable feedback for the 'thumbnailScore' field and critique notes.
                    
                    Format response strictly as JSON:
                    {
                      "thumbnailScore": 2,
                      "weakPoints": "<Specific visual issues found in the image, e.g. text contrast low on mobile>",
                      "competitorComparison": "<Actionable design suggestions compared to top US real estate channels>",
                      "subjectLine": "quick thumbnail idea for $channelName 🏡",
                      "naturalEmailBody": "<natural outreach email mentioning the visual thumbnail audit>",
                      "videoComment": "Great video walkthrough! Loved the market tips.",
                      "ctrHookIdea": "<high CTR text overlay idea>",
                      "thumbnailPrompt": "<Midjourney prompt for redesign>"
                    }
                """.trimIndent()

                val inputContent = content {
                    image(bitmap)
                    text(promptText)
                }

                val response = model.generateContent(inputContent)
                val text = response.text
                if (!text.isNullOrEmpty()) {
                    return@withContext parseJsonResponse(text, realtorName, channelName, recentVideoTitle, locationState, senderName)
                }
            }
            generateFallbackAudit(realtorName, channelName, recentVideoTitle, locationState, senderName)
        } catch (e: Exception) {
            Log.e("GeminiScoutEngine", "Error analyzing thumbnail vision", e)
            generateFallbackAudit(realtorName, channelName, recentVideoTitle, locationState, senderName)
        }
    }

    private fun downloadImageAsBitmap(imageUrl: String): android.graphics.Bitmap? {
        return try {
            val request = Request.Builder().url(imageUrl).build()
            val response = httpClient.newCall(request).execute()
            if (response.isSuccessful) {
                val bytes = response.body?.bytes()
                if (bytes != null && bytes.isNotEmpty()) {
                    BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                } else null
            } else null
        } catch (e: Exception) {
            null
        }
    }

    suspend fun processVoiceCommand(command: String, systemPrompt: String = ""): String = withContext(Dispatchers.IO) {
        try {
            val model = getGenerativeModel()
            if (model != null) {
                val response = model.generateContent("You are Thumbnail Scout AI Assistant. System Context: $systemPrompt. Respond in 2 short sentences in friendly Hinglish or English to this command: '$command'")
                return@withContext response.text ?: "Command executed: '$command'. Running automated scout scanning and outreach optimization."
            }
            "Command executed: '$command'. Running automated scout scanning and outreach optimization."
        } catch (e: Exception) {
            "Agent executed command: $command"
        }
    }

    private fun parseJsonResponse(
        jsonString: String,
        realtorName: String,
        channelName: String,
        recentVideoTitle: String,
        locationState: String,
        senderName: String
    ): GeneratedAuditResult {
        return try {
            val cleanJson = jsonString.substringAfter("{").substringBeforeLast("}")
            val jsonObject = JSONObject("{$cleanJson}")
            GeneratedAuditResult(
                thumbnailScore = jsonObject.optInt("thumbnailScore", 2),
                weakPoints = jsonObject.optString("weakPoints", "Text contrast is low and subject is uncropped, causing low click-through rate on mobile search."),
                competitorComparison = jsonObject.optString("competitorComparison", "Top US realtors in $locationState use bold 3-word hooks and warm HDR home interior lighting."),
                subjectLine = jsonObject.optString("subjectLine", "quick thumbnail idea for $channelName 🏡"),
                naturalEmailBody = jsonObject.optString("naturalEmailBody", "Hey $realtorName,\n\nCame across your recent video '$recentVideoTitle' while looking at $locationState real estate. Loved the neighborhood breakdown!\n\nNotice mobile viewers might be missing it because the current thumbnail text is a bit hard to read on small screens. I actually put together a free redesigned thumbnail concept for your channel with a bolder CTR hook.\n\nWould you mind if I email it over to you? No catch or fee at all—just wanted to share it!\n\nBest,\n$senderName"),
                videoComment = jsonObject.optString("videoComment", "Great breakdown of the $locationState market! Super helpful info."),
                ctrHookIdea = jsonObject.optString("ctrHookIdea", "INSIDE $850K $locationState HOME!"),
                thumbnailPrompt = jsonObject.optString("thumbnailPrompt", "Hyper-realistic luxury modern house exterior, golden hour lighting, bold modern typography overlay")
            )
        } catch (e: Exception) {
            generateFallbackAudit(realtorName, channelName, recentVideoTitle, locationState, senderName)
        }
    }

    private fun generateFallbackAudit(
        realtorName: String,
        channelName: String,
        recentVideoTitle: String,
        locationState: String,
        senderName: String
    ): GeneratedAuditResult {
        return GeneratedAuditResult(
            thumbnailScore = 2,
            weakPoints = "Current thumbnail lacks high-contrast focal points, cluttered font style, and low mobile visibility in search results.",
            competitorComparison = "Compared to top 5% US realtors in $locationState, the visual hook lacks warm interior framing and high-CTR price tag overlay.",
            subjectLine = "quick thumbnail idea for $channelName 🏡",
            naturalEmailBody = """
                Hey $realtorName,

                I was checking out real estate videos in $locationState and stumbled on your video "$recentVideoTitle". The content quality and market insights you shared were genuinely solid!

                I noticed the thumbnail on mobile isn't doing full justice to the video—the text is a bit hard to read against the background, which might be hurting your CTR despite great content.

                I'm a thumbnail designer focused on US real estate channels. I actually went ahead and created a free redesigned thumbnail concept specifically for this video with a bold visual hook.

                If you'd like to check it out, just reply to this email and I'll send the high-res file right over—completely free, no strings attached!

                Best regards,
                $senderName
            """.trimIndent(),
            videoComment = "Super informative walkthrough for $locationState! Really appreciate the honest market tips.",
            ctrHookIdea = "BUY OR WAIT IN $locationState?",
            thumbnailPrompt = "Modern luxury realtor standing in front of high-end glass mansion, dramatic sky, high contrast 4k HDR text overlay"
        )
    }
}
