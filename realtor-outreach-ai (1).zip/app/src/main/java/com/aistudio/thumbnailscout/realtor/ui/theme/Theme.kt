package com.aistudio.thumbnailscout.realtor.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = GoldAccent,
    onPrimary = DeepSlateBackground,
    primaryContainer = GoldAccentLight,
    secondary = EmeraldSuccess,
    onSecondary = DeepSlateBackground,
    background = DeepSlateBackground,
    surface = DarkNavySurface,
    onSurface = TextPrimaryLight,
    surfaceVariant = DarkNavySurfaceVariant,
    onSurfaceVariant = TextSecondaryLight,
    error = CoralCritical,
    outline = BorderStroke
)

private val LightColorScheme = lightColorScheme(
    primary = GoldAccent,
    onPrimary = Color.White,
    primaryContainer = GoldAccentLight,
    secondary = EmeraldSuccess,
    onSecondary = Color.White,
    background = LightBackground,
    surface = LightSurface,
    onSurface = TextPrimaryDark,
    surfaceVariant = Color(0xFFE2E8F0),
    onSurfaceVariant = TextSecondaryDark,
    error = CoralCritical,
    outline = Color(0xFFCBD5E1)
)

@Composable
fun ThumbnailScoutTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
