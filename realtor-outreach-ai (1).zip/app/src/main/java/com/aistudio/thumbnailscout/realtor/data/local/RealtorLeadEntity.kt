package com.aistudio.thumbnailscout.realtor.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "realtor_leads")
data class RealtorLeadEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val channelName: String = "",
    val email: String = "",
    val recentVideo: String = "",
    val status: String = "NEW",
    val lastMessage: String = "",

    // Fields for compatibility
    val channelUrl: String = "",
    val realtorName: String = "",
    val locationState: String = "",
    val subscriberCount: Int = 0,
    val avgViews: Int = 0,
    val videoUploadFrequencyDays: Int = 0,
    val repliesToComments: Boolean = false,
    val currentThumbnailRatingScore: Int = 0,
    val priority: String = "MEDIUM",
    val recentVideoTitle: String = "",
    val recentVideoUrl: String = "",
    val recentThumbnailUrl: String = "",
    val personalizedEmailSubject: String = "",
    val personalizedEmailBody: String = "",
    val videoCommentText: String = "",
    val thumbnailImprovementNote: String = "",
    val competitorBenchmarkComparison: String = "",
    val aiThumbnailConceptPrompt: String = "",
    val freeSampleSent: Boolean = false,
    val trackingPixelId: String = "",
    val abSubjectVariant: String = "Variant A",
    val openedTimestamp: Long = 0L,
    val openCount: Int = 0,
    val isSeen: Boolean = false,
    val lastContactedTimestamp: Long = 0L,
    val createdAtTimestamp: Long = System.currentTimeMillis()
)
