package com.aistudio.thumbnailscout.realtor.utils

import java.util.Properties
import javax.mail.Message
import javax.mail.PasswordAuthentication
import javax.mail.Session
import javax.mail.Transport
import javax.mail.internet.InternetAddress
import javax.mail.internet.MimeMessage

object GmailSender {
    fun sendEmail(
        senderEmail: String,
        appPassword: String,
        recipientEmail: String,
        subject: String,
        body: String
    ) {
        val props = Properties().apply {
            put("mail.smtp.auth", "true")
            put("mail.smtp.starttls.enable", "true")
            put("mail.smtp.host", "smtp.gmail.com")
            put("mail.smtp.port", "587")
        }

        val session = Session.getInstance(props, object : javax.mail.Authenticator() {
            override fun getPasswordAuthentication(): PasswordAuthentication {
                return PasswordAuthentication(senderEmail, appPassword)
            }
        })

        val message = MimeMessage(session).apply {
            setFrom(InternetAddress(senderEmail))
            setRecipient(Message.RecipientType.TO, InternetAddress(recipientEmail))
            setSubject(subject)
            setText(body)
        }

        Transport.send(message)
    }
}
