package com.aistudio.thumbnailscout.realtor.worker

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.aistudio.thumbnailscout.realtor.data.local.AppDatabase
import com.aistudio.thumbnailscout.realtor.data.local.SystemLogEntity
import com.aistudio.thumbnailscout.realtor.data.remote.EmailTrackingService
import com.aistudio.thumbnailscout.realtor.data.remote.TimezoneUtils

class EmailDispatchWorker(
    appContext: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(appContext, workerParams) {

    override suspend fun doWork(): Result {
        val leadId = inputData.getLong(KEY_LEAD_ID, -1L)
        if (leadId == -1L) return Result.failure()
        
        val targetTimezone = inputData.getString(KEY_TARGET_TIMEZONE) ?: "US/Eastern"
        val antiSpamIntervalSec = inputData.getLong(KEY_ANTI_SPAM_INTERVAL_SEC, 180L)

        val db = AppDatabase.getInstance(applicationContext)
        val leadDao = db.realtorLeadDao()
        val logDao = db.systemLogDao()
        val trackingService = EmailTrackingService()

        val lead = leadDao.getLeadById(leadId) ?: return Result.failure()

        if (lead.status == "SENT" || lead.status == "SEEN" || lead.status == "REPLIED" || lead.status == "CONVERTED") {
            logDao.insertLog(
                SystemLogEntity(
                    title = "⚠️ WorkManager Job Skipped",
                    message = "Lead ${lead.realtorName} is already in status '${lead.status}'.",
                    logType = "SYSTEM"
                )
            )
            return Result.success(workDataOf("status" to "SKIPPED_ALREADY_SENT"))
        }

        // Generate tracking pixel
        val pixelInfo = trackingService.generateTrackingPixel(lead.id)
        val bodyWithPixel = trackingService.injectTrackingPixel(lead.personalizedEmailBody, pixelInfo)

        val timeInZone = TimezoneUtils.getFormattedTimeInZone(targetTimezone)

        val updatedLead = lead.copy(
            status = "SENT",
            personalizedEmailBody = bodyWithPixel,
            trackingPixelId = pixelInfo.pixelId,
            isSeen = false,
            lastContactedTimestamp = System.currentTimeMillis()
        )

        leadDao.updateLead(updatedLead)

        // --- ACTUAL EMAIL DISPATCH START ---
        val gmailUser = com.aistudio.thumbnailscout.realtor.utils.AppSettingsManager.gmailUser
        val gmailPass = com.aistudio.thumbnailscout.realtor.utils.AppSettingsManager.gmailAppPass
        
        var dispatchSummary = "Delivered to ${lead.realtorName} (${lead.email})"
        var logType = "DISPATCH"

        if (gmailUser.isNotEmpty() && gmailPass.isNotEmpty()) {
            try {
                com.aistudio.thumbnailscout.realtor.utils.GmailSender.sendEmail(
                    senderEmail = gmailUser,
                    appPassword = gmailPass,
                    recipientEmail = lead.email,
                    subject = lead.personalizedEmailSubject,
                    body = bodyWithPixel
                )
                dispatchSummary += " via SMTP ✅"
            } catch (e: Exception) {
                dispatchSummary += " FAILED (SMTP Error: ${e.localizedMessage}) ❌"
                logType = "ERROR"
            }
        } else {
            dispatchSummary += " (SKIPPED: Missing Gmail App Password in Settings) ⚠️"
            logType = "WARNING"
        }
        // --- ACTUAL EMAIL DISPATCH END ---

        logDao.insertLog(
            SystemLogEntity(
                title = if (logType == "DISPATCH") "⚡ Email Dispatched" else "⚠️ Email Status: $logType",
                message = "$dispatchSummary in $targetTimezone [$timeInZone]. Anti-spam: ${antiSpamIntervalSec}s [Pixel: ${pixelInfo.pixelId}]",
                logType = logType
            )
        )

        return Result.success(
            workDataOf(
                "leadId" to leadId,
                "realtorName" to lead.realtorName,
                "sentTime" to timeInZone,
                "pixelId" to pixelInfo.pixelId
            )
        )
    }

    companion object {
        const val KEY_LEAD_ID = "key_lead_id"
        const val KEY_TARGET_TIMEZONE = "key_target_timezone"
        const val KEY_ANTI_SPAM_INTERVAL_SEC = "key_anti_spam_interval_sec"
        const val WORK_TAG_OUTREACH = "tag_realtor_outreach_dispatch"
        const val UNIQUE_WORK_NAME = "realtor_outreach_job_queue"
    }
}
