package com.aistudio.thumbnailscout.realtor.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun ClientHubScreen() {
    val context = LocalContext.current
    var clientMessage by remember { mutableStateOf("Hi Satish, I need a high CTR gaming thumbnail for my new YouTube video. Budget is $30.") }
    var hindiTranslation by remember { mutableStateOf("") }
    var aiDraftReply by remember { mutableStateOf("") }

    val portfolioUrl = "https://tinyurl.com/satish-thumbnails"
    val paypalUrl = "https://paypal.me/SatishDesigns"

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text("👑 Satish Designs - Client & Order Hub", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        Spacer(modifier = Modifier.height(12.dp))

        // Quick Links Bar
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(portfolioUrl))
                context.startActivity(intent)
            }, modifier = Modifier.weight(1f)) {
                Text("📁 View Portfolio")
            }
            Button(onClick = {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(paypalUrl))
                context.startActivity(intent)
            }, modifier = Modifier.weight(1f)) {
                Text("💳 PayPal Invoice")
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Incoming Client Request Card
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("📥 Latest Client Message (English):", fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(4.dp))
                Text(clientMessage)

                Spacer(modifier = Modifier.height(12.dp))

                // Hindi Translation Button
                Button(onClick = {
                    // Simulated Gemini / Local translation for user understanding
                    hindiTranslation = "नमस्ते सतीश, मुझे अपने नए यूट्यूब वीडियो के लिए एक हाई सीटीआर गेमिंग थंबनेल चाहिए। बजट $30 है।"
                }) {
                    Text("🇮🇳 Translate to Hindi (समझने के लिए)")
                }

                if (hindiTranslation.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("हिंदी अर्थ: $hindiTranslation", color = MaterialTheme.colorScheme.secondary, fontWeight = FontWeight.Medium)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // AI Auto-Drafted Reply & Actions
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("🤖 AI Auto-Drafted Response (Ready to Send):", fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(4.dp))
                Text("Hi! Thanks for reaching out. You can check my previous work here: $portfolioUrl. To proceed, please complete the payment securely via PayPal: $paypalUrl. I'll deliver within 24 hours!")

                Spacer(modifier = Modifier.height(12.dp))

                Button(onClick = {
                    // Send Email / Message Action with Staggering / Direct dispatch
                }, modifier = Modifier.fillMaxWidth()) {
                    Text("🚀 Send AI Reply & PayPal Link to Client")
                }
            }
        }
    }
}
