package com.aistudio.thumbnailscout.realtor.data.remote

import com.aistudio.thumbnailscout.realtor.data.local.RealtorLeadEntity
import java.util.UUID

class LeadDiscoveryEngine {

    fun generateInitialUSRealtorLeads(): List<RealtorLeadEntity> {
        val now = System.currentTimeMillis()
        return listOf(
            RealtorLeadEntity(
                id = 0L,
                channelName = "Miami Living with Marcus",
                channelUrl = "https://youtube.com/@miamilivingmarcus",
                realtorName = "Marcus Vance",
                email = "marcus.vance.realty@gmail.com",
                locationState = "Miami, FL",
                subscriberCount = 840,
                avgViews = 180,
                videoUploadFrequencyDays = 5,
                repliesToComments = true,
                currentThumbnailRatingScore = 1, // CRITICAL WEAK
                priority = "CRITICAL_HIGH",
                recentVideoTitle = "Touring a ${'$'}890k Modern Condo in Brickell Miami",
                recentVideoUrl = "https://youtube.com/watch?v=miami_brickell_tour",
                recentThumbnailUrl = "https://images.unsplash.com/photo-1560518883-ce09059eeffa?w=800",
                status = "DISCOVERED",
                personalizedEmailSubject = "quick thumbnail idea for Miami Living with Marcus 🏡",
                personalizedEmailBody = """
                    Hey Marcus,

                    Came across your Brickell Miami condo walkthrough video while checking Florida listings. You explained the HOA dues and market trends really clearly!

                    I noticed your current thumbnail uses dark navy text over a dark background, which makes it blend into YouTube dark mode on phones. 

                    I redesigned a custom high-CTR thumbnail mockup for your condo tour with a warm 3D text overlay and high-contrast border. I'd love to send it to you for free!

                    Let me know if I can drop it in your inbox!

                    Best,
                    Rahul (Thumbnail Specialist)
                """.trimIndent(),
                videoCommentText = "Great breakdown of Brickell HOA fees Marcus! Very clear walkthrough.",
                thumbnailImprovementNote = "Dark text on dark background, zero mobile contrast, no human face crop.",
                competitorBenchmarkComparison = "Miami luxury channels averaging 8.4% CTR use bright yellow price tags and zoomed headshots.",
                aiThumbnailConceptPrompt = "Modern Miami luxury penthouse balcony view, bright sunset, bold 3D text '${'$'}890K BRICKELL CONDO'",
                freeSampleSent = false,
                abSubjectVariant = "Variant A",
                createdAtTimestamp = now - 3600000L
            ),
            RealtorLeadEntity(
                id = 0L,
                channelName = "Dallas Homes & Relocation - Sarah",
                channelUrl = "https://youtube.com/@dallashomesbysarah",
                realtorName = "Sarah Jenkins",
                email = "sarah@jenkinsdallasrealty.com",
                locationState = "Dallas, TX",
                subscriberCount = 1250,
                avgViews = 310,
                videoUploadFrequencyDays = 4,
                repliesToComments = true,
                currentThumbnailRatingScore = 2, // WEAK
                priority = "CRITICAL_HIGH",
                recentVideoTitle = "Pros & Cons of Moving to Frisco Texas in 2026",
                recentVideoUrl = "https://youtube.com/watch?v=frisco_tx_pros_cons",
                recentThumbnailUrl = "https://images.unsplash.com/photo-1570129477492-45c003edd2be?w=800",
                status = "DISCOVERED",
                personalizedEmailSubject = "[Free Graphic] redesigned thumbnail for Pros & Cons of Moving to Frisco Texas in 2026",
                personalizedEmailBody = """
                    Hi Sarah,

                    Just watched your Frisco TX pros & cons video—your honest take on school districts and property tax rates was super insightful!

                    I noticed your video title is strong, but the thumbnail only shows a static house photo without any text hook or face framing, so casual scrollers might pass it by.

                    I put together a free high-CTR redesigned thumbnail mockup featuring a split 'PROS vs CONS' design specifically for your Frisco video.

                    Would you like me to send over the free design? No cost or catch at all!

                    Best,
                    Rahul
                """.trimIndent(),
                videoCommentText = "Super helpful breakdown on Frisco property taxes! Thanks Sarah.",
                thumbnailImprovementNote = "Generic stock house photo with no text hook, low visual interest.",
                competitorBenchmarkComparison = "Top DFW real estate creators use split screen 'DON'T MOVE HERE' emotion hooks.",
                aiThumbnailConceptPrompt = "Split screen Frisco Texas neighborhood vs Texas flag, bold text 'DONT MOVE TO FRISCO?'",
                freeSampleSent = false,
                abSubjectVariant = "Variant B",
                createdAtTimestamp = now - 7200000L
            ),
            RealtorLeadEntity(
                id = 0L,
                channelName = "LA Luxury Living - Kevin",
                channelUrl = "https://youtube.com/@kevinlaluxury",
                realtorName = "Kevin Ross",
                email = "kevin.ross.la.realtor@gmail.com",
                locationState = "Los Angeles, CA",
                subscriberCount = 1920,
                avgViews = 420,
                videoUploadFrequencyDays = 7,
                repliesToComments = true,
                currentThumbnailRatingScore = 2,
                priority = "HIGH",
                recentVideoTitle = "Inside a ${'$'}2,400,000 Modern Farmhouse in Pasadena CA",
                recentVideoUrl = "https://youtube.com/watch?v=pasadena_farmhouse",
                recentThumbnailUrl = "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=800",
                status = "DISCOVERED",
                personalizedEmailSubject = "Pasadena house tour feedback (+ quick thumbnail draft)",
                personalizedEmailBody = """
                    Hey Kevin,

                    Loved your walkthrough of the Pasadena modern farmhouse! The kitchen finishings and outdoor pool layout were stunning.

                    I noticed the thumbnail photo is slightly blurry on mobile screens and missing a price callout overlay. 

                    Since high-end LA buyers decide in 0.5 seconds, I designed a crisp HDR thumbnail redesign with glowing architectural lighting and a bold '${'$'}2.4M PASADENA' tag.

                    If you're open to seeing it, I'd love to send you the free graphic file!

                    Best,
                    Rahul
                """.trimIndent(),
                videoCommentText = "That Pasadena kitchen layout is incredible Kevin! Great video quality.",
                thumbnailImprovementNote = "Blurry exterior photo, missing price hook, unedited color grading.",
                competitorBenchmarkComparison = "LA real estate channels like Enes Yilmazer use 4k ultra-crisp HDR with bold price tags.",
                aiThumbnailConceptPrompt = "Ultra luxury modern Pasadena farmhouse at dusk with glowing lights, bold '${'$'}2.4M TOUR'",
                freeSampleSent = false,
                createdAtTimestamp = now - 14400000L
            ),
            RealtorLeadEntity(
                id = 0L,
                channelName = "Atlanta Living - Brandon Realtor",
                channelUrl = "https://youtube.com/@atlantalivingbrandon",
                realtorName = "Brandon Brooks",
                email = "brandon@atlantaareahomes.com",
                locationState = "Atlanta, GA",
                subscriberCount = 610,
                avgViews = 140,
                videoUploadFrequencyDays = 3,
                repliesToComments = true,
                currentThumbnailRatingScore = 1,
                priority = "CRITICAL_HIGH",
                recentVideoTitle = "Top 5 Neighborhoods in Alpharetta Georgia for Families",
                recentVideoUrl = "https://youtube.com/watch?v=alpharetta_neighborhoods",
                recentThumbnailUrl = "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=800",
                status = "DISCOVERED",
                personalizedEmailSubject = "quick thumbnail concept for Atlanta Living 🏡",
                personalizedEmailBody = """
                    Hey Brandon,

                    Awesome video on Alpharetta family neighborhoods! You gave really practical advise on commuting to downtown Atlanta.

                    I noticed your thumbnail thumbnail text is cut off on the sides and hard to read on mobile devices. 

                    I made a free revised thumbnail design for your Alpharetta video with clean visual typography and a map callout.

                    May I email the free design over to you? No charges at all!

                    Best,
                    Rahul
                """.trimIndent(),
                videoCommentText = "Alpharetta advice was spot-on Brandon! Appreciate the detailed commute tips.",
                thumbnailImprovementNote = "Text cutoff at edges, default font style, no spatial separation.",
                competitorBenchmarkComparison = "Atlanta relocate channels use map graphics and high-contrast text.",
                aiThumbnailConceptPrompt = "Map of Atlanta Alpharetta pin with modern house photo, bold 'TOP 5 NEIGHBORHOODS'",
                freeSampleSent = false,
                createdAtTimestamp = now - 28800000L
            ),
            RealtorLeadEntity(
                id = 0L,
                channelName = "Phoenix & Scottsdale Real Estate - Tyler",
                channelUrl = "https://youtube.com/@scottsdaletyler",
                realtorName = "Tyler Miller",
                email = "tyler@scottsdaleluxuryrealty.com",
                locationState = "Phoenix, AZ",
                subscriberCount = 1480,
                avgViews = 290,
                videoUploadFrequencyDays = 6,
                repliesToComments = true,
                currentThumbnailRatingScore = 2,
                priority = "HIGH",
                recentVideoTitle = "Scottsdale Arizona Housing Market Crisis or Opportunity?",
                recentVideoUrl = "https://youtube.com/watch?v=scottsdale_market_2026",
                recentThumbnailUrl = "https://images.unsplash.com/photo-1580587771525-78b9dba3b914?w=800",
                status = "DISCOVERED",
                personalizedEmailSubject = "Scottsdale market video thoughts + free thumbnail redesign",
                personalizedEmailBody = """
                    Hi Tyler,

                    Your analysis on Scottsdale inventory trends and interest rate impacts was super thorough!

                    I noticed the current thumbnail looks a bit like a slide deck graphic rather than an engaging YouTube video thumbnail.

                    I created a high-CTR desert luxury house thumbnail concept with a bold 'CRASH OR BOOM?' hook specifically for your channel.

                    Let me know if I can send it to your email—100% free!

                    Best,
                    Rahul
                """.trimIndent(),
                videoCommentText = "Really thorough inventory breakdown Tyler! Great insights for Arizona buyers.",
                thumbnailImprovementNote = "Slide-deck style graphic, no emotion hook, plain corporate font.",
                competitorBenchmarkComparison = "Market update channels use red/green trend arrows and dramatic headshots.",
                aiThumbnailConceptPrompt = "Scottsdale desert mansion with upward trend arrow, bold text 'SCOTTSDALE MARKET CRASH?'",
                freeSampleSent = false,
                createdAtTimestamp = now - 43200000L
            )
        )
    }

    fun scanNewUSRealtors(keyword: String): List<RealtorLeadEntity> {
        val states = listOf("Miami, FL", "Dallas, TX", "Austin, TX", "Tampa, FL", "Seattle, WA", "Denver, CO", "Nashville, TN", "Charlotte, NC")
        val now = System.currentTimeMillis()
        val randomState = states.random()
        val uniqueId = "lead_scan_${UUID.randomUUID().toString().take(6)}"

        return listOf(
            RealtorLeadEntity(
                id = 0L,
                channelName = "$keyword Specialist - Real Estate",
                channelUrl = "https://youtube.com/@realtor_${uniqueId}",
                realtorName = "Alex Morgan",
                email = "alex.morgan.realtor.${uniqueId.take(4)}@gmail.com",
                locationState = randomState,
                subscriberCount = (400..1800).random(),
                avgViews = (100..350).random(),
                videoUploadFrequencyDays = (3..7).random(),
                repliesToComments = true,
                currentThumbnailRatingScore = (1..2).random(), // WEAK
                priority = "CRITICAL_HIGH",
                recentVideoTitle = "What ${'$'}650,000 Gets You in $randomState (Full House Tour)",
                recentVideoUrl = "https://youtube.com/watch?v=$uniqueId",
                recentThumbnailUrl = "https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=800",
                status = "DISCOVERED",
                personalizedEmailSubject = "quick thumbnail concept for $keyword ($randomState) 🏡",
                personalizedEmailBody = """
                    Hey Alex,

                    Saw your recent $randomState house tour video! The kitchen island and backyard layout were fantastic.

                    I noticed your current video thumbnail lacks a mobile CTR hook and high-contrast framing. 

                    I drafted a free redesigned high-CTR thumbnail for this exact video. If you'd like to take a look, I'll send the free design right over!

                    Best,
                    Rahul
                """.trimIndent(),
                videoCommentText = "Great tour Alex! Loved the backyard layout in $randomState.",
                thumbnailImprovementNote = "Low contrast lighting, missing bold price tag overlay.",
                competitorBenchmarkComparison = "Local $randomState channels gaining 10k+ views use warm dusk lighting and bright text tags.",
                aiThumbnailConceptPrompt = "Luxury house exterior in $randomState, golden sunset, text tag '${'$'}650K HOUSE TOUR'",
                freeSampleSent = false,
                abSubjectVariant = if (uniqueId.hashCode() % 2 == 0) "Variant A" else "Variant B",
                createdAtTimestamp = now
            )
        )
    }
}
