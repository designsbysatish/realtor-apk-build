package com.aistudio.thumbnailscout.realtor.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aistudio.thumbnailscout.realtor.data.local.RealtorLeadEntity
import com.aistudio.thumbnailscout.realtor.data.remote.DispatchProgressState
import com.aistudio.thumbnailscout.realtor.ui.theme.EmeraldSuccess
import com.aistudio.thumbnailscout.realtor.ui.theme.GoldAccent
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun OutreachedBoxScreen(
    outreachedLeads: List<RealtorLeadEntity>,
    dispatchState: DispatchProgressState,
    targetTimezone: String,
    onLeadClick: (RealtorLeadEntity) -> Unit,
    onBulkDispatchClick: () -> Unit,
    onSimulatePixelOpen: (RealtorLeadEntity) -> Unit = {},
    onWorkManagerQueueClick: ((antiSpamSec: Long, businessHours: Boolean) -> Unit)? = null,
    onCancelWorkManagerClick: (() -> Unit)? = null
) {
    val totalSent = outreachedLeads.size
    val seenCount = outreachedLeads.count { it.isSeen || it.status == "SEEN" || it.status == "REPLIED" }
    val unseenCount = totalSent - seenCount
    val openRate = if (totalSent > 0) (seenCount * 100 / totalSent) else 0

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // WorkManager Staggered Queue Control Box
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(GoldAccent.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Schedule,
                                contentDescription = null,
                                tint = GoldAccent,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "WorkManager Anti-Spam Queue",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Staggered across US Timezones (EST/CST/MST/PST)",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    if (onWorkManagerQueueClick != null) {
                        Button(
                            onClick = { onWorkManagerQueueClick(180L, true) },
                            colors = ButtonDefaults.buttonColors(containerColor = GoldAccent),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = "⏱️ Queue WorkManager",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimary
                            )
                        }
                    }
                }

                if (dispatchState.statusMessage.isNotBlank()) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .padding(8.dp)
                    ) {
                        Text(
                            text = dispatchState.statusMessage,
                            fontSize = 11.sp,
                            color = GoldAccent,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }

                if (dispatchState.isWorkManagerActive && onCancelWorkManagerClick != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(
                        onClick = onCancelWorkManagerClick,
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "🛑 Cancel WorkManager Job Queue",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onError
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Email Open Tracking Metrics Row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("DELIVERED", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("$totalSent", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("SEEN 👁️", fontSize = 9.sp, color = GoldAccent)
                        Text("$seenCount", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = GoldAccent)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("UNSEEN ✉️", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("$unseenCount", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("OPEN RATE", fontSize = 9.sp, color = EmeraldSuccess)
                        Text("$openRate%", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = EmeraldSuccess)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        Text(
            text = "Sent & Active Outreached Leads (${outreachedLeads.size})",
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
        )

        Spacer(modifier = Modifier.height(8.dp))

        if (outreachedLeads.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No emails sent yet. Select leads from New Leads box and click 1-Click Send.",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            LazyColumn(modifier = Modifier.fillMaxSize()) {
                items(outreachedLeads, key = { it.id }) { lead ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clickable { onLeadClick(lead) }
                            .testTag("outreached_item_${lead.id}")
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(MaterialTheme.colorScheme.surfaceVariant),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = if (lead.status == "SEEN") Icons.Default.Visibility else Icons.Default.Email,
                                    contentDescription = null,
                                    tint = if (lead.status == "SEEN") GoldAccent else EmeraldSuccess,
                                    modifier = Modifier.size(18.dp)
                                )
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = lead.realtorName,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = lead.locationState,
                                        fontSize = 11.sp,
                                        color = GoldAccent
                                    )
                                }

                                Text(
                                    text = lead.personalizedEmailSubject,
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )

                                Spacer(modifier = Modifier.height(4.dp))

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(
                                                when (lead.status) {
                                                    "SEEN" -> GoldAccent.copy(alpha = 0.2f)
                                                    "REPLIED" -> EmeraldSuccess.copy(alpha = 0.3f)
                                                    else -> EmeraldSuccess.copy(alpha = 0.2f)
                                                }
                                            )
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = when (lead.status) {
                                                "SEEN" -> "OPENED / SEEN 👁️"
                                                "REPLIED" -> "CONVERTED / REPLIED 🎉"
                                                else -> "DELIVERED ✉️"
                                            },
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.ExtraBold,
                                            color = if (lead.status == "SEEN") GoldAccent else EmeraldSuccess
                                        )
                                    }

                                    Spacer(modifier = Modifier.width(8.dp))

                                    val dateStr = if (lead.lastContactedTimestamp > 0) {
                                        SimpleDateFormat("MMM dd, hh:mm a", Locale.US).format(Date(lead.lastContactedTimestamp))
                                    } else "Recently"

                                    Text(
                                        text = dateStr,
                                        fontSize = 10.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
