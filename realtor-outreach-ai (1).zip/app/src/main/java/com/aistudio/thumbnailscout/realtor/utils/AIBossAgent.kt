package com.aistudio.thumbnailscout.realtor.utils

import android.content.Context
import android.media.MediaPlayer
import android.speech.tts.TextToSpeech
import android.widget.Toast
import java.util.Locale

class AIBossAgent(private val context: Context) : TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var isTtsInitialized = false

    init {
        tts = TextToSpeech(context, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale("hi", "IN")) // Hindi Voice Support
            if (result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED) {
                isTtsInitialized = true
            }
        }
    }

    // 1. Voice aur Text mein daant kar Daily Target dena
    fun scoldAndGiveTarget(completedOutreach: Int, targetOutreach: Int, monthlyEarnings: Int) {
        val message: String
        if (completedOutreach < targetOutreach) {
            val pending = targetOutreach - completedOutreach
            message = "ओए सतीश! उठ, फोन उठा! आज का टारगेट $targetOutreach आउटरीच का था, तूने सिर्फ $completedOutreach किए हैं। अभी भी $pending बाकी हैं। चैटिंग बंद कर और काम पर लग जा, वरना इस महीने $2000 डॉलर कमाने का सपना सपना ही रह जाएगा!"
        } else {
            message = "शाबाश सतीश! तूने आज का टारगेट पूरा कर लिया है। ऐसे ही मेहनत करता रह, डॉलर की बारिश होगी!"
        }

        // Text display/toast
        Toast.makeText(context, "🤖 AI BOSS: $message", Toast.LENGTH_LONG).show()

        // Voice mein bolna (Speech)
        if (isTtsInitialized) {
            tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, null)
        }
    }

    // 2. Email Seen hone par Alarm / Alert bajana
    fun triggerEmailSeenAlert(clientName: String) {
        Toast.makeText(context, "🚨 ALARM: $clientName ne tera email dekh liya hai! Turant follow-up bhej!", Toast.LENGTH_LONG).show()
        playAlertSound()
    }

    // 3. Client Reply aane par High Alert
    fun triggerClientReplyAlert(clientName: String, replyText: String) {
        val alertMsg = "🔔 BADA ALERT! Client $clientName ne reply kar diya hai: \"$replyText\". Fatafat PayPal link bhej aur deal close kar!"
        Toast.makeText(context, alertMsg, Toast.LENGTH_LONG).show()
        
        if (isTtsInitialized) {
            // Corrected typo QUEUE_FLUNCH to QUEUE_FLUSH
            tts?.speak("सुन सतीश! $clientName का रिप्लाई आ गया है। जल्दी से ऐप खोल और डील पक्की कर!", TextToSpeech.QUEUE_FLUSH, null, null)
        }
    }

    private fun playAlertSound() {
        try {
            // App ke andar default notification beep ya alarm play karne ke liye
            val mediaPlayer = MediaPlayer.create(context, android.provider.Settings.System.DEFAULT_NOTIFICATION_URI)
            mediaPlayer.start()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
    }
}
