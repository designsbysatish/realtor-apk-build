package com.aistudio.thumbnailscout.ai

data class ThumbnailSample(
    val optionNumber: Int,
    val headline: String,
    val visualStyle: String,
    val colorScheme: String,
    val pricingOffer: String = "$10 | Unlimited Revisions"
)

class AIThumbnailGenerator {
    fun generateThumbnailSamples(channelName: String, videoTopic: String): List<ThumbnailSample> {
        // AI Analysis simulation to generate 3 high-converting concepts for the realtor/client
        return listOf(
            ThumbnailSample(
                optionNumber = 1,
                headline = "SELL FAST in $channelName!",
                visualStyle = "Close-up face expression + Modern luxury home background + Big bold yellow text",
                colorScheme = "High Contrast Blue & Yellow",
                pricingOffer = "$10 | Unlimited Revisions"
            ),
            ThumbnailSample(
                optionNumber = 2,
                headline = "HIDDEN TRUTH about $videoTopic",
                visualStyle = "Shocked reaction cutout + Red arrow pointing to a key detail or price drop",
                colorScheme = "Dark Moody Theme with Neon Red Highlight",
                pricingOffer = "$10 | Unlimited Revisions"
            ),
            ThumbnailSample(
                optionNumber = 3,
                headline = "STOP Losing Money!",
                visualStyle = "Split screen layout (Before vs After) + Clean professional font",
                colorScheme = "Vibrant Green & Clean White",
                pricingOffer = "$10 | Unlimited Revisions"
            )
        )
    }
}
