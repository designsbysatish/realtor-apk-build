package com.aistudio.thumbnailscout.realtor.data.remote

import retrofit2.http.GET
import retrofit2.http.Query

interface YouTubeApiService {
    @GET("youtube/v3/search")
    suspend fun searchRealtors(
        @Query("part") part: String = "snippet",
        @Query("q") query: String,
        @Query("type") type: String = "channel",
        @Query("regionCode") regionCode: String = "US",
        @Query("maxResults") maxResults: Int,
        @Query("key") apiKey: String
    ): YoutubeSearchResponse

    @GET("youtube/v3/channels")
    suspend fun getChannelDetails(
        @Query("part") part: String = "snippet,statistics",
        @Query("id") channelId: String,
        @Query("key") apiKey: String
    ): YoutubeChannelResponse

    @GET("youtube/v3/search")
    suspend fun getChannelVideos(
        @Query("part") part: String = "snippet",
        @Query("channelId") channelId: String,
        @Query("order") order: String = "date",
        @Query("maxResults") maxResults: Int = 1,
        @Query("key") apiKey: String
    ): YoutubeSearchResponse
}

data class YoutubeSearchResponse(val items: List<SearchItem>)
data class SearchItem(val id: SearchId, val snippet: Snippet)
data class SearchId(val videoId: String?, val channelId: String?)
data class Snippet(val title: String, val description: String, val thumbnails: ThumbnailDetails, val publishedAt: String)
data class ThumbnailDetails(val high: ThumbnailUrl)
data class ThumbnailUrl(val url: String)

data class YoutubeChannelResponse(val items: List<ChannelItem>)
data class ChannelItem(val statistics: Statistics, val snippet: Snippet)
data class Statistics(val subscriberCount: String, val viewCount: String, val videoCount: String)
