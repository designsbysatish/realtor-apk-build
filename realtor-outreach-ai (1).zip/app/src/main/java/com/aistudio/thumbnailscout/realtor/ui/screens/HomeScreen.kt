package com.aistudio.thumbnailscout.realtor.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aistudio.thumbnailscout.realtor.data.local.RealtorLeadEntity
import com.aistudio.thumbnailscout.realtor.data.local.SystemLogEntity
import com.aistudio.thumbnailscout.realtor.ui.theme.CoralCritical
import com.aistudio.thumbnailscout.realtor.ui.theme.EmeraldSuccess
import com.aistudio.thumbnailscout.realtor.ui.theme.GoldAccent

@Composable
fun HomeScreen(
    leadCount: Int,
    outreachedCount: Int,
    repliedCount: Int,
    recentLogs: List<SystemLogEntity>,
    highPriorityLeads: List<RealtorLeadEntity>,
    onLeadClick: (RealtorLeadEntity) -> Unit,
    onVoiceAssistantClick: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            HomeHeader(onVoiceAssistantClick)
        }

        item {
            StatsGrid(leadCount, outreachedCount, repliedCount)
        }

        item {
            Text("🔥 Critical Weak Thumbnails (Targets)", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = GoldAccent)
        }

        if (highPriorityLeads.isEmpty()) {
            item {
                EmptyLeadsCard()
            }
        } else {
            items(highPriorityLeads.take(4)) { lead ->
                QuickLeadCard(lead, onLeadClick)
            }
        }

        item {
            Text("🛰️ Live Agent Activity Logs", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = GoldAccent)
        }

        items(recentLogs.take(5)) { log ->
            LogItem(log)
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun HomeHeader(onVoiceAssistantClick: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(
                text = "Home Dashboard",
                fontSize = 24.sp,
                fontWeight = FontWeight.ExtraBold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(EmeraldSuccess))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "AI AGENT ACTIVE (24/7)",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = EmeraldSuccess
                )
            }
        }

        IconButton(
            onClick = onVoiceAssistantClick,
            modifier = Modifier
                .size(48.dp)
                .clip(CircleShape)
                .background(GoldAccent.copy(alpha = 0.15f))
        ) {
            Icon(Icons.Default.Mic, contentDescription = "Voice Assistant", tint = GoldAccent)
        }
    }
}

@Composable
fun StatsGrid(leads: Int, outreach: Int, replies: Int) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        StatCard("Total Leads", leads.toString(), Icons.Default.Groups, Modifier.weight(1f))
        StatCard("Outreached", outreach.toString(), Icons.Default.Send, Modifier.weight(1f))
        StatCard("Conversions", replies.toString(), Icons.Default.AutoAwesome, Modifier.weight(1f))
    }
}

@Composable
fun StatCard(title: String, value: String, icon: ImageVector, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Icon(icon, contentDescription = null, tint = GoldAccent, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.height(8.dp))
            Text(value, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
            Text(title, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun QuickLeadCard(lead: RealtorLeadEntity, onClick: (RealtorLeadEntity) -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick(lead) },
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(CoralCritical.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Text(lead.currentThumbnailRatingScore.toString(), fontWeight = FontWeight.Bold, color = CoralCritical)
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(lead.channelName, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1)
                Text("${lead.subscriberCount} Subs • ${lead.locationState}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = MaterialTheme.colorScheme.outline)
        }
    }
}

@Composable
fun EmptyLeadsCard() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
    ) {
        Box(modifier = Modifier.padding(24.dp), contentAlignment = Alignment.Center) {
            Text("No high-priority weak targets found yet.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
fun LogItem(log: SystemLogEntity) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.Top
    ) {
        Box(
            modifier = Modifier
                .size(6.dp)
                .clip(CircleShape)
                .background(if (log.logType == "ERROR") CoralCritical else GoldAccent)
                .padding(top = 6.dp)
        )
        Spacer(modifier = Modifier.width(10.dp))
        Column {
            Text(log.title, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Text(log.message, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, lineHeight = 14.sp)
        }
    }
}
