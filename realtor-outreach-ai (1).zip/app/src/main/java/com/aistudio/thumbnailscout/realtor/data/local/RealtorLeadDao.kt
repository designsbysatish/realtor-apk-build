package com.aistudio.thumbnailscout.realtor.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface RealtorLeadDao {
    @Query("SELECT * FROM realtor_leads ORDER BY currentThumbnailRatingScore ASC, createdAtTimestamp DESC")
    fun getAllLeads(): Flow<List<RealtorLeadEntity>>

    @Query("SELECT * FROM realtor_leads ORDER BY currentThumbnailRatingScore ASC, createdAtTimestamp DESC")
    suspend fun getAllLeadsList(): List<RealtorLeadEntity>

    @Query("SELECT * FROM realtor_leads WHERE priority = :priority ORDER BY currentThumbnailRatingScore ASC")
    fun getLeadsByPriority(priority: String): Flow<List<RealtorLeadEntity>>

    @Query("SELECT * FROM realtor_leads WHERE status = :status ORDER BY currentThumbnailRatingScore ASC")
    fun getLeadsByStatus(status: String): Flow<List<RealtorLeadEntity>>

    @Query("SELECT * FROM realtor_leads WHERE status = :status ORDER BY currentThumbnailRatingScore ASC")
    suspend fun getLeadsByStatusList(status: String): List<RealtorLeadEntity>

    @Query("SELECT * FROM realtor_leads WHERE id = :id")
    suspend fun getLeadById(id: Long): RealtorLeadEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLead(lead: RealtorLeadEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLeads(leads: List<RealtorLeadEntity>)

    @Update
    suspend fun updateLead(lead: RealtorLeadEntity)

    @Delete
    suspend fun deleteLead(lead: RealtorLeadEntity)

    @Query("DELETE FROM realtor_leads")
    suspend fun clearAllLeads()

    @Query("SELECT COUNT(*) FROM realtor_leads")
    suspend fun getLeadCountList(): Int

    @Query("SELECT COUNT(*) FROM realtor_leads")
    fun getLeadCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM realtor_leads WHERE status = 'SENT' OR status = 'SEEN' OR status = 'REPLIED'")
    fun getOutreachedCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM realtor_leads WHERE status = 'REPLIED' OR status = 'CONVERTED'")
    fun getRepliedCount(): Flow<Int>
}
