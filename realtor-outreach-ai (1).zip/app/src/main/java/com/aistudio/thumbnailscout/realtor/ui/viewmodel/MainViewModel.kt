package com.aistudio.thumbnailscout.realtor.ui.viewmodel

import android.app.Application
import android.speech.tts.TextToSpeech
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.aistudio.thumbnailscout.realtor.data.UserPreferences
import com.aistudio.thumbnailscout.realtor.data.local.AppDatabase
import com.aistudio.thumbnailscout.realtor.data.local.RealtorLeadEntity
import com.aistudio.thumbnailscout.realtor.data.local.SystemLogEntity
import com.aistudio.thumbnailscout.realtor.data.remote.ABTestMetrics
import com.aistudio.thumbnailscout.realtor.data.remote.DispatchProgressState
import com.aistudio.thumbnailscout.realtor.data.remote.DispatchScheduler
import com.aistudio.thumbnailscout.realtor.data.remote.EmailTrackingMetrics
import com.aistudio.thumbnailscout.realtor.data.remote.GeminiScoutEngine
import com.aistudio.thumbnailscout.realtor.data.remote.LeadDiscoveryEngine
import com.aistudio.thumbnailscout.realtor.data.repository.RealtorRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.Locale

sealed class NavigationTab {
    object Home : NavigationTab()
    object LeadsBox : NavigationTab()
    object ScanDiscovery : NavigationTab()
    object OutreachedBox : NavigationTab()
    object AnalyticsTracker : NavigationTab()
    object Settings : NavigationTab()
    object ClientHub : NavigationTab()
    object DiagnosticTest : NavigationTab()
}

class MainViewModel(application: Application) : AndroidViewModel(application), TextToSpeech.OnInitListener {

    private val db = AppDatabase.getInstance(application)
    val preferences = UserPreferences(application)
    private val geminiEngine = GeminiScoutEngine()
    private val leadEngine = LeadDiscoveryEngine()
    private val dispatchScheduler = DispatchScheduler(application, db.realtorLeadDao(), db.systemLogDao())

    val repository = RealtorRepository(
        leadDao = db.realtorLeadDao(),
        logDao = db.systemLogDao(),
        preferences = preferences,
        geminiEngine = geminiEngine,
        leadDiscoveryEngine = leadEngine,
        dispatchScheduler = dispatchScheduler
    )

    private val _currentTab = MutableStateFlow<NavigationTab>(NavigationTab.Home)
    val currentTab: StateFlow<NavigationTab> = _currentTab.asStateFlow()

    private val _selectedLead = MutableStateFlow<RealtorLeadEntity?>(null)
    val selectedLead: StateFlow<RealtorLeadEntity?> = _selectedLead.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _filterCategory = MutableStateFlow("ALL") // "ALL", "WEAK_PRIORITY", "NEW", "SENT", "SEEN", "REPLIED"
    val filterCategory: StateFlow<String> = _filterCategory.asStateFlow()

    private val _selectedPriorityCategory = MutableStateFlow("ALL") // "ALL", "HIGH", "NORMAL"
    val selectedPriorityCategory: StateFlow<String> = _selectedPriorityCategory.asStateFlow()

    private val _selectedOutreachStatus = MutableStateFlow("ALL") // "ALL", "PENDING", "SENT", "SEEN", "REPLIED"
    val selectedOutreachStatus: StateFlow<String> = _selectedOutreachStatus.asStateFlow()

    private val _isScanning = MutableStateFlow(false)
    val isScanning: StateFlow<Boolean> = _isScanning.asStateFlow()

    private val _voiceOutputMessage = MutableStateFlow("")
    val voiceOutputMessage: StateFlow<String> = _voiceOutputMessage.asStateFlow()

    private val _themeMode = MutableStateFlow(preferences.themeMode)
    val themeMode: StateFlow<String> = _themeMode.asStateFlow()

    private val _isDemoMode = MutableStateFlow(preferences.isDemoMode)
    val isDemoMode: StateFlow<Boolean> = _isDemoMode.asStateFlow()

    private var tts: TextToSpeech? = null

    init {
        viewModelScope.launch {
            repository.initializePreloadedLeadsIfEmpty()
        }
        if (preferences.voiceFeedbackEnabled) {
            tts = TextToSpeech(application, this)
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale.US
        }
    }

    val allLeads: StateFlow<List<RealtorLeadEntity>> = repository.allLeads
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val filteredLeads: StateFlow<List<RealtorLeadEntity>> = combine(
        allLeads,
        _searchQuery,
        _filterCategory,
        _selectedPriorityCategory,
        _selectedOutreachStatus
    ) { leads, query, pillFilter, priorityFilter, statusFilter ->
        leads.filter { lead ->
            val matchesQuery = query.isEmpty() ||
                    lead.channelName.contains(query, ignoreCase = true) ||
                    lead.realtorName.contains(query, ignoreCase = true) ||
                    lead.locationState.contains(query, ignoreCase = true) ||
                    lead.recentVideoTitle.contains(query, ignoreCase = true)

            val matchesPill = when (pillFilter) {
                "WEAK_PRIORITY" -> lead.currentThumbnailRatingScore <= 2
                "DISCOVERED" -> lead.status == "DISCOVERED" || lead.status == "AUDITED"
                "SENT" -> lead.status == "SENT" || lead.status == "SEEN"
                "REPLIED" -> lead.status == "REPLIED" || lead.status == "CONVERTED"
                else -> true
            }

            val matchesPriority = when (priorityFilter) {
                "HIGH" -> lead.priority.contains("HIGH", ignoreCase = true) || lead.currentThumbnailRatingScore <= 3
                "NORMAL" -> lead.priority.equals("MEDIUM", ignoreCase = true) || lead.currentThumbnailRatingScore > 3
                else -> true
            }

            val matchesStatus = when (statusFilter) {
                "PENDING" -> lead.status == "DISCOVERED" || lead.status == "AUDITED" || lead.status == "OUTREACH_DRAFTED"
                "SENT" -> lead.status == "SENT"
                "SEEN" -> lead.status == "SEEN" || lead.isSeen || lead.openCount > 0
                "REPLIED" -> lead.status == "REPLIED" || lead.status == "CONVERTED"
                else -> true
            }

            matchesQuery && matchesPill && matchesPriority && matchesStatus
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val recentLogs: StateFlow<List<SystemLogEntity>> = repository.recentLogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val totalLeadCount: StateFlow<Int> = repository.leadCount
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val outreachedCount: StateFlow<Int> = repository.outreachedCount
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val repliedCount: StateFlow<Int> = repository.repliedCount
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val dispatchProgress: StateFlow<DispatchProgressState> = repository.dispatchProgress

    val trackingMetrics: StateFlow<EmailTrackingMetrics> = allLeads.map { leads ->
        repository.trackingService.computeTrackingMetrics(leads)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), EmailTrackingMetrics(0, 0, 0, 0))

    val abTestMetrics: StateFlow<ABTestMetrics> = allLeads.map { leads ->
        repository.trackingService.computeABTestMetrics(leads)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), ABTestMetrics(0, 0, 0, 0, 0, 0, "Tied", 0))

    fun switchTab(tab: NavigationTab) {
        _currentTab.value = tab
    }

    fun selectLead(lead: RealtorLeadEntity?) {
        _selectedLead.value = lead
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setFilterCategory(category: String) {
        _filterCategory.value = category
    }

    fun setPriorityCategory(priority: String) {
        _selectedPriorityCategory.value = priority
    }

    fun setOutreachStatus(status: String) {
        _selectedOutreachStatus.value = status
    }

    fun resetFilters() {
        _searchQuery.value = ""
        _filterCategory.value = "ALL"
        _selectedPriorityCategory.value = "ALL"
        _selectedOutreachStatus.value = "ALL"
    }

    fun scanNewLeads(keyword: String) {
        viewModelScope.launch {
            _isScanning.value = true
            speakVoice("Scanning US real estate channels for keyword $keyword with weak thumbnails...")
            repository.performLiveChannelScan(keyword)
            _isScanning.value = false
            speakVoice("Scan complete. New high priority realtor leads added to your queue.")
        }
    }

    fun regenerateAuditForSelectedLead() {
        val lead = _selectedLead.value ?: return
        viewModelScope.launch {
            repository.reAnalyzeLeadWithGemini(lead)
            // refresh selected lead
            val updated = db.realtorLeadDao().getLeadById(lead.id)
            if (updated != null) {
                _selectedLead.value = updated
            }
            speakVoice("Refreshed personalized email and CTR thumbnail strategy for ${lead.realtorName}.")
        }
    }

    fun auditThumbnailWithGeminiVision(lead: RealtorLeadEntity? = null) {
        val target = lead ?: _selectedLead.value ?: return
        viewModelScope.launch {
            _isScanning.value = true
            speakVoice("Analyzing thumbnail image with Gemini Vision API for ${target.channelName}...")
            repository.auditThumbnailWithGeminiVision(target)
            val updated = db.realtorLeadDao().getLeadById(target.id)
            if (updated != null) {
                _selectedLead.value = updated
            }
            _isScanning.value = false
            speakVoice("Gemini Vision image audit complete. Thumbnail score updated to ${updated?.currentThumbnailRatingScore} out of 10.")
        }
    }

    fun updateLeadEmailDraft(subject: String, body: String, comment: String) {
        val current = _selectedLead.value ?: return
        viewModelScope.launch {
            val updated = current.copy(
                personalizedEmailSubject = subject,
                personalizedEmailBody = body,
                videoCommentText = comment
            )
            repository.updateLead(updated)
            _selectedLead.value = updated
        }
    }

    fun launchSingleOutreachInGmail(lead: RealtorLeadEntity) {
        repository.launchGmailForLead(lead)
        speakVoice("Opened email client for ${lead.realtorName}.")
    }

    fun launchGmailForLead(lead: RealtorLeadEntity) {
        launchSingleOutreachInGmail(lead)
    }

    fun startBulkAutomatedOutreach(leadsToSend: List<RealtorLeadEntity>) {
        if (leadsToSend.isEmpty()) return
        speakVoice("Initiating 1-Click bulk email queue for ${leadsToSend.size} realtors...")
        repository.startAutomatedDripDispatch(leadsToSend)
    }

    fun scheduleWorkManagerOutreachQueue(
        leadsToSend: List<RealtorLeadEntity>,
        antiSpamIntervalSec: Long = 180L,
        respectBusinessHours: Boolean = true
    ) {
        if (leadsToSend.isEmpty()) return
        speakVoice("Queued ${leadsToSend.size} realtors in WorkManager with anti-spam staggered delays.")
        repository.scheduleWorkManagerOutreachQueue(
            leads = leadsToSend,
            minAntiSpamIntervalSec = antiSpamIntervalSec,
            respectBusinessHours = respectBusinessHours
        )
    }

    fun cancelWorkManagerQueue() {
        repository.cancelWorkManagerQueue()
        speakVoice("Cancelled WorkManager outreach queue.")
    }

    val availableOutreachTemplates = repository.templateGenerator.availableTemplates

    fun applyOutreachTemplate(lead: RealtorLeadEntity, templateId: String, preferredVariant: String = "AUTO") {
        viewModelScope.launch {
            val updated = repository.applyTemplateToLead(lead, templateId, preferredVariant)
            _selectedLead.value = updated
            speakVoice("Applied ${updated.abSubjectVariant} template for ${lead.realtorName}")
        }
    }

    fun toggleABVariantForLead(lead: RealtorLeadEntity) {
        val nextVariant = if (lead.abSubjectVariant.contains("A")) "Variant B" else "Variant A"
        val templateId = repository.templateGenerator.availableTemplates.first().id
        applyOutreachTemplate(lead, templateId, nextVariant)
    }

    fun simulateABTestOpenPings() {
        viewModelScope.launch {
            val leadsList = db.realtorLeadDao().getAllLeadsList()
            if (leadsList.isEmpty()) return@launch
            
            // Randomly select 2-3 leads to trigger tracking pixel pings
            val candidates = leadsList.shuffled().take(3)
            for (lead in candidates) {
                repository.simulatePixelOpenForLead(lead)
            }
            speakVoice("Simulated A/B open rate pings across active variants.")
        }
    }

    fun markLeadAsReplied(lead: RealtorLeadEntity) {
        viewModelScope.launch {
            val updated = lead.copy(status = "REPLIED")
            repository.updateLead(updated)
            _selectedLead.value = updated
            speakVoice("Marked ${lead.realtorName} as replied! Great job on converting this lead.")
        }
    }

    fun simulatePixelOpen(lead: RealtorLeadEntity) {
        viewModelScope.launch {
            repository.simulatePixelOpenForLead(lead)
            val updated = db.realtorLeadDao().getLeadById(lead.id)
            if (updated != null) {
                _selectedLead.value = updated
            }
            speakVoice("Simulated tracking pixel trigger for ${lead.realtorName}. Email status updated to Seen!")
        }
    }

    fun processAgentVoiceCommand(commandText: String) {
        viewModelScope.launch {
            val response = repository.processVoiceCommand(commandText)
            _voiceOutputMessage.value = response
            speakVoice(response)

            // Auto actions if command matches keywords
            if (commandText.contains("scan", ignoreCase = true) || commandText.contains("find", ignoreCase = true)) {
                scanNewLeads("Florida Realtor")
            } else if (commandText.contains("send", ignoreCase = true) || commandText.contains("dispatch", ignoreCase = true)) {
                val ready = filteredLeads.value.filter { it.status == "DISCOVERED" || it.status == "AUDITED" }
                startBulkAutomatedOutreach(ready)
            }
        }
    }

    fun updateSenderName(newName: String) {
        preferences.senderName = newName
    }

    fun updateTargetTimezone(newTz: String) {
        preferences.targetTimezone = newTz
    }

    fun updateDispatchDelaySec(seconds: Int) {
        preferences.dispatchDelaySeconds = seconds
    }

    fun updateThemeMode(mode: String) {
        preferences.themeMode = mode
        _themeMode.value = mode
    }

    fun toggleDemoMode(enabled: Boolean) {
        preferences.isDemoMode = enabled
        _isDemoMode.value = enabled
        speakVoice(if (enabled) "Demo mode enabled. Showcasing premium features to clients." else "Demo mode disabled.")
    }

    fun updateAiSystemPrompt(prompt: String) {
        preferences.aiSystemPrompt = prompt
        speakVoice("AI System instructions updated. Strategy set to: $prompt")
    }

    fun speakVoice(text: String) {
        if (preferences.voiceFeedbackEnabled && tts != null) {
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "AgentVoice")
        }
    }

    override fun onCleared() {
        super.onCleared()
        tts?.stop()
        tts?.shutdown()
    }
}
